using Amazon;
using Amazon.Runtime;
using Amazon.SimpleSystemsManagement;
using Amazon.SimpleSystemsManagement.Model;
using AwsParameterStore;
using Microsoft.AspNetCore.Mvc;

namespace Test_ParameterStore.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public WeatherForecastController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        private static readonly string[] Summaries = new[]
        {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

        //private readonly ILogger<WeatherForecastController> _logger;

        //public WeatherForecastController(ILogger<WeatherForecastController> logger)
        //{
        //    _logger = logger;
        //}

        //[HttpGet(Name = "GetWeatherForecast")]
        //public IEnumerable<WeatherForecast> Get()
        //{
        //    return Enumerable.Range(1, 5).Select(index => new WeatherForecast
        //    {
        //        Date = DateTime.Now.AddDays(index),
        //        TemperatureC = Random.Shared.Next(-20, 55),
        //        Summary = Summaries[Random.Shared.Next(Summaries.Length)]
        //    })
        //    .ToArray();
        //}


        [HttpGet(Name = "GetWeatherForecast")]
        public async Task<string> Get()
        {
            string parameter = string.Empty;

            try
            {
                string AccessKeyId = "AKIATASLNGBAFJKJNCDD";
                string SecretAccessKey = "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";

                //var credentials = new BasicAWSCredentials(AccessKeyId, SecretAccessKey);
                //var client = new AmazonSimpleSystemsManagementClient(
                //            credentials, RegionEndpoint.USEast1);

                //var request = new GetParameterRequest()
                //{
                //    Name = "weather-forecast-count"
                //};
                //var result = client.GetParameterAsync(request);
                //return parameter = result.pa .ToString();
                //AwsParameterStoreClient client = new AwsParameterStoreClient(Amazon.RegionEndpoint.USEast1);

                //var value = client.GetValueAsync("weather-forecast-count");
                //return Convert.ToString(value);

                //var ssmClient = new AmazonSimpleSystemsManagementClient(Amazon.RegionEndpoint.USEast1);

                //var response = ssmClient.GetParameterAsync(new GetParameterRequest
                //{
                //    Name = "weather-forecast-count",
                //    //WithDecryption = true
                //});

                //return response.Parameter.Value;
                // AwsParameterStoreClient client = new AwsParameterStoreClient(Amazon.RegionEndpoint.USEast1);
                var credentials = new BasicAWSCredentials(AccessKeyId, SecretAccessKey);

                var ssmClient = new AmazonSimpleSystemsManagementClient(credentials, Amazon.RegionEndpoint.USEast1);

                //var value = client.GetValueAsync("weather-forecast-count");
                // var value = client.GetValueAsync("weather-forecast-count").Result;
                var response = await ssmClient.GetParameterAsync(new GetParameterRequest
                {
                    Name = "trending-moat-connection"
                    //WithDecryption = true
                });


                return Convert.ToString(response.Parameter.Value);

            }
            catch (Exception ex)
            {
                return parameter;
            }
        }
    }
}