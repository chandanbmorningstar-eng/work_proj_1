# database-resources

## Initialization
```bash
cd infrastructure/database-resources
npm install
```

## Deployment
```bash
npx serverless deploy --stage {stage} --region us-east-1
```

Change state to `stg`, `uat`, or `prod` as needed.

