"""
Thin SQS consumer Lambda.

Receives SQS batch events from the Event Source Mapping and forwards them
to the existing ASP.NET Core API Gateway endpoint (POST /process-metadata-updates).
The controller handles the business logic; this Lambda only bridges the event format.

The Lambda returns a batchItemFailures response so SQS can retry only the
messages that the API reported as failed, rather than the entire batch.
"""

import json
import os
import urllib.request
import urllib.error


def handler(event, context):
    records = event.get("Records", [])
    if not records:
        return {"batchItemFailures": []}

    api_url = os.environ["API_GATEWAY_URL"]   # e.g. https://xxx.execute-api.us-east-1.amazonaws.com/prod/process-metadata-updates
    api_key = os.environ.get("API_GATEWAY_KEY", "")

    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["x-api-key"] = api_key

    # Forward the SQS batch payload as-is; SQSBatchRequest in the controller
    # maps directly onto the SQS event shape (Records[].messageId / body).
    payload = json.dumps(event).encode("utf-8")
    req = urllib.request.Request(api_url, data=payload, headers=headers, method="POST")

    try:
        # Leave 5 s headroom vs. the Lambda timeout (30 s)
        with urllib.request.urlopen(req, timeout=25) as response:
            result = json.loads(response.read().decode("utf-8"))
            # The controller returns {"batchItemFailures": [{"itemIdentifier": "..."}]}
            # Return it directly so SQS handles partial failures correctly.
            return result

    except urllib.error.HTTPError as e:
        error_body = e.read().decode("utf-8") if e.fp else "(no body)"
        print(f"[ERROR] HTTP {e.code} from API endpoint: {error_body}")
        # Report every record as failed so SQS retries the whole batch
        return _all_failed(records)

    except Exception as e:  # noqa: BLE001 — network/timeout errors
        print(f"[ERROR] Could not reach API endpoint: {e}")
        return _all_failed(records)


def _all_failed(records):
    return {
        "batchItemFailures": [
            {"itemIdentifier": r["messageId"]} for r in records
        ]
    }
