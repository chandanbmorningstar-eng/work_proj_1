# SQS Infrastructure Deployment Guide

Complete step-by-step instructions for deploying the Stripe metadata updates SQS infrastructure.

## Prerequisites

1. **AWS Account**: Requires us-east-1 region (or update `terraform/main.tf`)
2. **Terraform**: v1.0 or later
3. **AWS CLI**: For verification
4. **Access**:
   - IAM permissions: SQS, Lambda, CloudWatch, IAM
   - AWS credentials configured locally

## Architecture Quick Reference

```
CSV Pipeline (fast, < 30 sec)
   └─→ SQS FIFO Queue
        └─→ Lambda Consumer (reserved concurrency: 2)
             └─→ Stripe API (~2 calls/sec)
                  └─→ Customer webhook
                       └─→ DynamoDB update
```

## Step 1: Prepare Terraform Environment

```bash
# Navigate to terraform directory
cd c:\Repositories\Individual Investors\min-backend\Newsletters\terraform

# Validate Terraform configuration
terraform validate

# Format code
terraform fmt -recursive .

# List all resources that will be created
terraform plan -json | jq '.resource_changes[] | .type'
```

**Expected Output**:
- `aws_sqs_queue` (main queue)
- `aws_sqs_queue` (DLQ)
- `aws_sqs_queue_policy`
- `aws_lambda_event_source_mapping`
- `aws_cloudwatch_metric_alarm` (2x)
- `aws_iam_role_policy` (if new)

## Step 2: Configure Terraform Variables

```bash
# Copy example file
Copy-Item terraform.tfvars.example terraform.tfvars

# Edit with actual values
# - consumer_lambda_function_name: your Lambda function
# - consumer_lambda_role_arn: your Lambda execution role
```

**Example terraform.tfvars**:
```hcl
environment = "prod"
consumer_lambda_function_name = "newsletters-stripe-metadata-consumer"
consumer_lambda_role_arn = "arn:aws:iam::123456789012:role/NewslettersLambdaExecutionRole"
```

## Step 3: Plan Terraform Deployment

```bash
# Generate execution plan
terraform plan -out=tfplan

# Review the plan - should show:
# - 1 SQS queue (FIFO)
# - 1 DLQ queue (FIFO)
# - 1 Queue policy
# - 1 Lambda event source mapping
# - 2 CloudWatch alarms
# - IAM policies
```

## Step 4: Deploy Infrastructure

```bash
# Apply Terraform configuration
terraform apply tfplan

# Verify deployment
$queueUrl = terraform output -raw stripe_metadata_updates_queue_url
Write-Host "Queue URL: $queueUrl"

# Verify queue exists
aws sqs list-queues --region us-east-1 | jq '.QueueUrls[]'
```

**Success Indicators**:
- Queue URL in output: `https://sqs.us-east-1.amazonaws.com/ACCOUNT_ID/newsletters-stripe-metadata-updates.fifo`
- DLQ URL in output
- No errors in CloudFormation events

## Step 5: Verify SQS Configuration

```bash
# Get queue attributes
aws sqs get-queue-attributes `
  --queue-url "https://sqs.us-east-1.amazonaws.com/ACCOUNT_ID/newsletters-stripe-metadata-updates.fifo" `
  --attribute-names All `
  --region us-east-1 | jq '.Attributes'
```

**Expected Attributes**:
- `FifoQueue`: true
- `ContentBasedDeduplication`: true
- `VisibilityTimeout`: 60
- `RedrivePolicy`: Contains DLQ reference

## Step 6: Configure Application

Update `src/Newsletters/appsettings.json`:

```json
{
  "SQSConfig": {
    "StripeMetadataUpdateQueueUrl": "https://sqs.us-east-1.amazonaws.com/ACCOUNT_ID/newsletters-stripe-metadata-updates.fifo"
  }
}
```

## Step 7: Configure Lambda

### Option A: Using AWS Console

1. Go to Lambda → Your Function
2. Add trigger: SQS
   - Queue: `newsletters-stripe-metadata-updates.fifo`
   - Batch size: 1
   - Batch window: 0
   - Function response types: ReportBatchItemFailures
3. Go to Concurrency → Reserved concurrency: 2

### Option B: Using Terraform (if managing Lambda in same config)

Add to your Lambda Terraform:
```hcl
resource "aws_lambda_function_event_invoke_config" "consumer" {
  function_name                = aws_lambda_function.consumer.function_name
  maximum_event_age_in_seconds = 3600
  maximum_retry_attempts       = 0
}

resource "aws_lambda_provisioned_concurrency_config" "consumer" {
  function_name                     = aws_lambda_function.consumer.function_name
  provisioned_concurrent_executions = 2
}
```

### Option C: Using AWS CLI

```bash
# Add SQS trigger
aws lambda create-event-source-mapping `
  --event-source-arn "arn:aws:sqs:us-east-1:ACCOUNT_ID:newsletters-stripe-metadata-updates.fifo" `
  --function-name newsletters-stripe-metadata-consumer `
  --batch-size 1 `
  --function-response-types ReportBatchItemFailures `
  --region us-east-1

# Set reserved concurrency
aws lambda put-function-concurrency `
  --function-name newsletters-stripe-metadata-consumer `
  --reserved-concurrent-executions 2 `
  --region us-east-1
```

## Step 8: Deploy Application

1. Build .NET solution:
   ```bash
   dotnet build Newsletters.sln
   ```

2. Publish Lambda function:
   ```bash
   dotnet publish -c Release -o publish
   # Package and upload to Lambda
   ```

3. Or use existing CI/CD pipeline to deploy

## Step 9: Test Workflow

### Test 1: Publish Sample Message

```bash
# Publish test message
aws sqs send-message `
  --queue-url "https://sqs.us-east-1.amazonaws.com/ACCOUNT_ID/newsletters-stripe-metadata-updates.fifo" `
  --message-body '{"SubscriptionId":"test-123","ProductCode":"MDI","ProdItem":"Issue-001","LastFulfillmentDate":"2026-07-15"}' `
  --message-group-id "MDI" `
  --region us-east-1
```

### Test 2: Monitor Lambda Logs

```bash
# Watch Lambda logs
aws logs tail /aws/lambda/newsletters-stripe-metadata-consumer --follow --region us-east-1
```

**Expected log output**:
```
Processing message: SubscriptionId=test-123, ProductCode=MDI
Updating Stripe subscription: sub_...
Successfully updated metadata
Message deleted from queue
```

### Test 3: Run Print Subscription CSV Pipeline

Trigger the CSV generation that publishes metadata updates:
- Production pipeline or
- Manual trigger via API endpoint

Monitor:
```bash
# Check queue depth
aws sqs get-queue-attributes `
  --queue-url "..." `
  --attribute-names ApproximateNumberOfMessages,ApproximateNumberOfMessagesNotVisible `
  --region us-east-1
```

## Step 10: Monitor & Alert Setup

### CloudWatch Dashboard

```bash
# Create custom dashboard showing:
# - Queue depth (messages visible + in-flight)
# - Lambda invocations
# - Lambda duration
# - Lambda errors
# - DLQ depth
```

### Set Alarms

Alarms already configured in `sqs_lambda_consumer.tf`:
- **DLQ not empty**: Messages failed after 3 retries
- **Queue delay**: Processing lag > 5 minutes

Check alarms:
```bash
aws cloudwatch describe-alarms `
  --alarm-name-prefix newsletters-stripe-metadata `
  --region us-east-1
```

## Troubleshooting

### Issue: Lambda not consuming messages

**Diagnostics**:
```bash
# Check event source mapping
aws lambda list-event-source-mappings `
  --event-source-arn "arn:aws:sqs:..." `
  --region us-east-1
```

**Fixes**:
1. Verify Lambda execution role has SQS permissions
2. Check Lambda reserved concurrency > 0
3. Verify event source mapping is enabled

### Issue: Messages in DLQ

**Diagnostics**:
```bash
# Check DLQ messages
aws sqs receive-message `
  --queue-url "..." `
  --max-number-of-messages 10 `
  --region us-east-1 | jq '.Messages[].Body'
```

**Common Causes**:
1. Stripe API rate limiting (increase visibility timeout, reduce concurrency)
2. Invalid subscription ID in message
3. Lambda timeout (increase timeout in Lambda config)
4. Network connectivity issues (Lambda → Stripe)

### Issue: High queue depth

**Diagnostics**:
```bash
aws sqs get-queue-attributes `
  --queue-url "..." `
  --attribute-names ApproximateNumberOfMessages `
  --region us-east-1
```

**Fixes**:
1. Increase Lambda reserved concurrency (default: 2, try 5-10)
2. Check Lambda duration → increase timeout if needed
3. Verify Stripe API is not rate limiting (check CloudWatch logs)
4. Scale Lambda by reducing visibility timeout

## Cleanup

To remove all SQS infrastructure:

```bash
# View what will be destroyed
terraform plan -destroy

# Destroy infrastructure
terraform destroy -auto-approve
```

**Note**: This will delete:
- Main queue (any messages will be lost)
- DLQ (any failed messages will be lost)
- Lambda event source mappings
- CloudWatch alarms

## Performance Targets

| Metric | Target | Current |
|--------|--------|---------|
| CSV Pipeline Duration | < 30 sec | ✓ (no API calls) |
| Stripe API Rate | 2 calls/sec | ✓ (reserved concurrency) |
| Metadata Update Latency | < 5 min | ✓ (1-2 sec per message) |
| Message Retry Count | 3 attempts | ✓ (SQS default) |
| DLQ Depth | 0 messages | Monitor |

## Rollback Plan

If issues arise after deployment:

1. **Pause Pipeline**: Don't publish new messages to SQS
2. **Disable Event Source**: `aws lambda delete-event-source-mapping`
3. **Investigate**: Check DLQ and CloudWatch logs
4. **Revert**: `terraform destroy` then redeploy once fixed

## Support

- **Terraform Issues**: Check `terraform apply` output
- **AWS Issues**: Check CloudWatch logs and X-Ray traces
- **Lambda Issues**: Check `/aws/lambda/newsletters-stripe-metadata-consumer`
- **Stripe Issues**: Check Stripe Dashboard → Webhooks and API logs
