# SQS Infrastructure for Stripe Metadata Updates

This Terraform configuration sets up the AWS SQS infrastructure for decoupling the print fulfillment CSV pipeline from Stripe metadata API calls, addressing rate limiting issues.

## Architecture Overview

The SQS solution implements the following flow:

```
CSV Generation Lambda (instant)
    ↓
Publish 4000+ messages to SQS (batches of 10)
    ↓
SQS FIFO Queue (newsletters-stripe-metadata-updates.fifo)
    ├─ Visibility Timeout: 60s
    ├─ Max Receive Count: 3
    └─ Message Grouping: By ProductCode
    ↓
Consumer Lambda (reservedConcurrency: 2)
    ├─ Processes 1 message at a time
    ├─ Calls Stripe API → UpdateSubscription metadata
    └─ Returns batch item failures for retries
    ↓
Stripe Webhook: customer.subscription.updated
    ↓
Existing Handler: ProcessCustomerSubscriptionUpdatedPayload
    ├─ Receives webhook with updated metadata
    ├─ Triggers HandlePrintSubscriptionWebhook
    └─ Updates DynamoDB: LastFulfillmentDate, IssueFulfilled
    ↓
DynamoDB: print-subscriptions table (updated)
```

## Files

| File | Purpose |
|------|---------|
| `sqs.tf` | Main SQS queue and DLQ resources |
| `sqs_variables.tf` | Input variables for SQS configuration |
| `sqs_lambda_consumer.tf` | Lambda event source mapping and monitoring |
| `README.md` | This file |

## Key Features

### 1. FIFO Queue
- **Name**: `newsletters-stripe-metadata-updates.fifo`
- **MessageGroupId**: ProductCode (ensures per-product ordering)
- **Content Deduplication**: Enabled (for idempotency)
- **Visibility Timeout**: 60 seconds

### 2. Dead Letter Queue (DLQ)
- **Name**: `newsletters-stripe-metadata-updates-dlq.fifo`
- **Max Receive Count**: 3 (messages go to DLQ after 3 failed attempts)
- **Retention**: 14 days (for investigation)

### 3. Consumer Lambda Configuration
- **Batch Size**: 1 (process one message at a time)
- **Reserved Concurrency**: 2 (limits to ~2 Stripe API calls/second)
- **Function Response Types**: ReportBatchItemFailures
- **Visibility Timeout**: 60s (per-message processing time)

## Deployment

### Prerequisites
1. AWS credentials configured locally or in CI/CD
2. Terraform >= 1.0
3. Existing Lambda function for consuming messages

### Step 1: Update Variables

Create or update `terraform.tfvars`:

```hcl
environment                    = "prod"
consumer_lambda_function_name  = "newsletters-stripe-metadata-consumer"
consumer_lambda_role_arn       = "arn:aws:iam::ACCOUNT_ID:role/NewslettersLambdaExecutionRole"

# Optional: Customize timeouts if needed
stripe_metadata_update_queue_visibility_timeout = 60
stripe_metadata_update_queue_max_receive_count = 3
```

### Step 2: Deploy with Terraform

```bash
cd terraform

# Validate configuration
terraform validate

# Plan deployment
terraform plan -out=tfplan

# Apply changes
terraform apply tfplan
```

### Step 3: Retrieve Queue URL

The Terraform outputs provide the queue URL to configure in your application:

```bash
terraform output stripe_metadata_updates_queue_url
```

### Step 4: Update Application Configuration

Update `appsettings.json`:

```json
{
  "SQSConfig": {
    "StripeMetadataUpdateQueueUrl": "https://sqs.us-east-1.amazonaws.com/ACCOUNT_ID/newsletters-stripe-metadata-updates.fifo"
  }
}
```

### Step 5: Configure Consumer Lambda

The consumer Lambda (`.NET` or other) must:
1. Be triggered by SQS Event Source Mapping
2. Have reserved concurrency: 2
3. Implement partial batch failure response

Example Lambda trigger (in `sqs_lambda_consumer.tf`):

```hcl
resource "aws_lambda_event_source_mapping" "stripe_metadata_updates_consumer" {
  event_source_arn  = aws_sqs_queue.stripe_metadata_updates.arn
  function_name     = "newsletters-stripe-metadata-consumer"
  batch_size        = 1
  function_response_types = ["ReportBatchItemFailures"]
}
```

## Monitoring & Troubleshooting

### CloudWatch Metrics
The Terraform includes alarms for:
- **DLQ not empty**: Messages failed after 3 retries
- **Queue delay**: Messages older than 5 minutes (processing lag)

### Check Queue Status

```bash
# List queues
aws sqs list-queues --region us-east-1

# Get queue attributes
aws sqs get-queue-attributes \
  --queue-url "https://sqs.us-east-1.amazonaws.com/ACCOUNT_ID/newsletters-stripe-metadata-updates.fifo" \
  --attribute-names "All" \
  --region us-east-1

# Get DLQ status
aws sqs receive-message \
  --queue-url "https://sqs.us-east-1.amazonaws.com/ACCOUNT_ID/newsletters-stripe-metadata-updates-dlq.fifo" \
  --region us-east-1 \
  --max-number-of-messages 10
```

### Troubleshooting Failed Messages

1. **Messages in DLQ**: Check `sqs_lambda_consumer.logs` in CloudWatch
2. **High visibility timeout**: Increase `stripe_metadata_update_queue_visibility_timeout` if Lambda processing takes >60s
3. **Stripe rate limiting still occurring**: Reduce `reservedConcurrency` to 1 (one call/second) in Lambda config

## Cost Estimates (Monthly)

| Component | Pricing | Cost |
|-----------|---------|------|
| 4,000 messages × 4 products | $0.40 per 1M messages | ~$0.007 |
| 2 consumer Lambda calls/sec | $0.20 per 1M invocations | ~$0.052 |
| **Total** | — | **~$0.06** |

## Performance Improvements

### Before (Synchronous Metadata Updates)
- **Pipeline Duration**: 15-45 minutes
- **Rate Limited**: Frequently (429 errors)
- **Stripe API Calls**: 24,000+ per run

### After (SQS-Buffered)
- **Pipeline Duration**: < 30 seconds (CSV pipeline completes)
- **Rate Limited**: Never (paced at 2 calls/sec)
- **Stripe API Calls**: Same 4,000+ but spread over time
- **DynamoDB Updates**: Automatic via webhook (no circular dependency)

## Cleanup

To remove SQS infrastructure:

```bash
terraform destroy -auto-approve
```

## Related Files

- **Application Config**: `src/Newsletters/appsettings.json` → `SQSConfig:StripeMetadataUpdateQueueUrl`
- **Publisher Service**: `Newsletters.Infrastructure/Services/AWS/SQSPublisherService.cs`
- **Consumer Service**: `Newsletters.Infrastructure/Services/AWS/SQSConsumerService.cs`
- **Controller Endpoint**: `src/Newsletters/Controllers/SQSConsumerController.cs`
