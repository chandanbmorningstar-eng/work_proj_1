# Main Terraform Configuration for Newsletters SQS Infrastructure
# This file orchestrates the SQS setup for Stripe metadata updates

terraform {
  required_version = ">= 1.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }

  # Uncomment to use remote state
  # backend "s3" {
  #   bucket         = "newsletters-terraform-state"
  #   key            = "sqs/terraform.tfstate"
  #   region         = "us-east-1"
  #   encrypt        = true
  #   dynamodb_table = "terraform-locks"
  # }
}

provider "aws" {
  region = "us-east-1"

  default_tags {
    tags = {
      Project     = "Newsletters"
      Environment = var.environment
      ManagedBy   = "Terraform"
      Purpose     = "Stripe Metadata Updates"
    }
  }
}

# Local variables for common configurations
locals {
  queue_name = "newsletters-stripe-metadata-updates"
  dlq_name   = "newsletters-stripe-metadata-updates-dlq"
}

# Module outputs summary
output "sqs_infrastructure" {
  description = "SQS infrastructure outputs for Stripe metadata updates"
  value = {
    queue_url              = aws_sqs_queue.stripe_metadata_updates.url
    queue_arn              = aws_sqs_queue.stripe_metadata_updates.arn
    dlq_url                = aws_sqs_queue.stripe_metadata_updates_dlq.url
    dlq_arn                = aws_sqs_queue.stripe_metadata_updates_dlq.arn
    consumer_lambda_name   = var.consumer_lambda_function_name
    reserved_concurrency   = var.consumer_lambda_reserved_concurrency
  }
  sensitive = false
}

output "next_steps" {
  description = "Steps to complete the deployment"
  value = [
    "1. Update appsettings.json with SQSConfig.StripeMetadataUpdateQueueUrl = '${aws_sqs_queue.stripe_metadata_updates.url}'",
    "2. Configure Lambda Event Source Mapping (see sqs_lambda_consumer.tf)",
    "3. Set Lambda reserved_concurrent_executions = ${var.consumer_lambda_reserved_concurrency}",
    "4. Deploy .NET application with updated configuration",
    "5. Monitor CloudWatch logs and SQS metrics"
  ]
}
