# SQS FIFO Dead Letter Queue for failed Stripe metadata updates
resource "aws_sqs_queue" "stripe_metadata_updates_dlq" {
  name                      = "newsletters-stripe-metadata-updates-dlq.fifo"
  fifo_queue                = true
  content_based_deduplication = true
  message_retention_seconds = var.stripe_metadata_dlq_retention_seconds

  tags = {
    Name        = "newsletters-stripe-metadata-updates-dlq"
    Environment = var.environment
    Project     = "Newsletters"
  }
}

# SQS FIFO Main Queue for Stripe metadata updates
resource "aws_sqs_queue" "stripe_metadata_updates" {
  name                      = "newsletters-stripe-metadata-updates.fifo"
  fifo_queue                = true
  content_based_deduplication = true
  visibility_timeout_seconds = var.stripe_metadata_update_queue_visibility_timeout
  message_retention_seconds = var.stripe_metadata_update_queue_retention_seconds
  max_message_size          = 262144 # 256 KB (default)

  # Redrive policy - messages that fail after max_receive_count are sent to DLQ
  redrive_policy = jsonencode({
    deadLetterTargetArn = aws_sqs_queue.stripe_metadata_updates_dlq.arn
    maxReceiveCount     = var.stripe_metadata_update_queue_max_receive_count
  })

  tags = {
    Name        = "newsletters-stripe-metadata-updates"
    Environment = var.environment
    Project     = "Newsletters"
  }

  depends_on = [aws_sqs_queue.stripe_metadata_updates_dlq]
}

# Queue Policy - Allow the thin SQS consumer Lambda execution role to consume messages
resource "aws_sqs_queue_policy" "stripe_metadata_updates_policy" {
  queue_url = aws_sqs_queue.stripe_metadata_updates.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect    = "Allow"
        Principal = { AWS = aws_iam_role.sqs_thin_consumer.arn }
        Action = [
          "sqs:ReceiveMessage",
          "sqs:DeleteMessage",
          "sqs:GetQueueAttributes",
          "sqs:ChangeMessageVisibility"
        ]
        Resource = aws_sqs_queue.stripe_metadata_updates.arn
      }
    ]
  })
}

# Outputs for use in other Terraform modules or application config
output "stripe_metadata_updates_queue_url" {
  description = "URL of the SQS queue for Stripe metadata updates"
  value       = aws_sqs_queue.stripe_metadata_updates.url
}

output "stripe_metadata_updates_queue_arn" {
  description = "ARN of the SQS queue for Stripe metadata updates"
  value       = aws_sqs_queue.stripe_metadata_updates.arn
}

output "stripe_metadata_updates_dlq_url" {
  description = "URL of the dead letter queue for Stripe metadata updates"
  value       = aws_sqs_queue.stripe_metadata_updates_dlq.url
}

output "stripe_metadata_updates_dlq_arn" {
  description = "ARN of the dead letter queue for Stripe metadata updates"
  value       = aws_sqs_queue.stripe_metadata_updates_dlq.arn
}
