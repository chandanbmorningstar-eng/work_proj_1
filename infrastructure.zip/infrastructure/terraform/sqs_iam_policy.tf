# SQS IAM permissions are now managed by the thin consumer Lambda's own role.
# See sqs_thin_consumer.tf: aws_iam_role_policy.sqs_thin_consumer
#
# The ASP.NET Core Lambda (var.consumer_lambda_role_arn) no longer needs
# SQS permissions because it is not triggered directly by SQS.
# If the ASP.NET core Lambda ever needs to *publish* to SQS (via SQSPublisherService),
# grant only sqs:SendMessage on the queue ARN via its existing execution role policy.
