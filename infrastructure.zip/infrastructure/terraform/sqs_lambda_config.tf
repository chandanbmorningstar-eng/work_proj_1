# Lambda Consumer Function Configuration
# This file defines the Stripe metadata update consumer Lambda function

variable "consumer_lambda_function_name" {
  description = "Name of the Lambda function that consumes SQS messages"
  type        = string
  default     = "newsletters-stripe-metadata-consumer"
}

variable "consumer_lambda_reserved_concurrency" {
  description = "Reserved concurrency for consumer Lambda (controls API rate limit)"
  type        = number
  default     = 2
}

variable "consumer_lambda_timeout" {
  description = "Timeout in seconds for consumer Lambda function"
  type        = number
  default     = 30
}

variable "consumer_lambda_memory_size" {
  description = "Memory size in MB for consumer Lambda function"
  type        = number
  default     = 512
}

variable "consumer_lambda_role_arn" {
  description = "ARN of the Lambda execution role"
  type        = string
}

variable "consumer_lambda_function_version" {
  description = "Published Lambda function version used by the live alias"
  type        = string
  default     = "1"
}

variable "create_consumer_lambda_alias" {
  description = "Whether to create a Lambda alias for the existing consumer function"
  type        = bool
  default     = false
}

variable "consumer_lambda_alias_name" {
  description = "Alias name to create for the consumer Lambda"
  type        = string
  default     = "live"
}

variable "enable_consumer_provisioned_concurrency" {
  description = "Whether to configure provisioned concurrency for the consumer Lambda alias"
  type        = bool
  default     = false
}

variable "create_consumer_log_group" {
  description = "Whether to create a CloudWatch log group for the consumer Lambda"
  type        = bool
  default     = false
}

variable "enable_consumer_event_invoke_config" {
  description = "Whether to configure Lambda async invoke settings for the consumer Lambda"
  type        = bool
  default     = false
}

# Lambda Reserved Concurrency - this controls the Stripe API rate limit
# With value of 2, Lambda can process at most 2 concurrent invocations
# This translates to ~2 Stripe API calls per second
resource "aws_lambda_provisioned_concurrency_config" "stripe_metadata_consumer" {
  count                             = var.enable_consumer_provisioned_concurrency && var.create_consumer_lambda_alias ? 1 : 0
  function_name                     = var.consumer_lambda_function_name
  provisioned_concurrent_executions = var.consumer_lambda_reserved_concurrency
  qualifier                         = aws_lambda_alias.stripe_metadata_consumer[0].name
}

# Lambda Alias for provisioned concurrency
resource "aws_lambda_alias" "stripe_metadata_consumer" {
  count            = var.create_consumer_lambda_alias ? 1 : 0
  name             = var.consumer_lambda_alias_name
  description      = "Live alias for Stripe metadata consumer"
  function_name    = var.consumer_lambda_function_name
  function_version = var.consumer_lambda_function_version
}

# Optional: CloudWatch Log Group for Lambda
resource "aws_cloudwatch_log_group" "stripe_metadata_consumer_logs" {
  count             = var.create_consumer_log_group ? 1 : 0
  name              = "/aws/lambda/${var.consumer_lambda_function_name}"
  retention_in_days = 7

  tags = {
    Name    = "stripe-metadata-consumer-logs"
    Project = "Newsletters"
  }
}

# Optional: Lambda Dead Letter Config (for tracking processing failures)
resource "aws_lambda_function_event_invoke_config" "stripe_metadata_consumer" {
  count                       = var.enable_consumer_event_invoke_config ? 1 : 0
  function_name          = var.consumer_lambda_function_name
  maximum_event_age_in_seconds = 3600 # 1 hour
  maximum_retry_attempts = 0    # Don't retry - let SQS handle retries

  destination_config {
    on_failure {
      destination = aws_sqs_queue.stripe_metadata_updates_dlq.arn
    }
  }
}

# NOTE: When using your existing .NET Lambda for both REST API and SQS consuming,
# you don't need separate Lambda provisioning. Instead, add this to your Lambda config:
# 
# 1. In CloudFormation/SAM template or Terraform aws_lambda_function:
#    reserved_concurrent_executions = 2
#
# 2. In event source mapping (already in sqs_lambda_consumer.tf):
#    batch_size = 1
#    function_response_types = ["ReportBatchItemFailures"]
#
# 3. In application code (SQSConsumerService.cs):
#    - Handles partial batch failures
#    - Throws on transient errors (SQS retries)
#    - Returns success/failure status
