# This file demonstrates how to configure the SQS-triggered Lambda consumer
# for processing Stripe metadata updates from the queue.
# Include this in your main Terraform configuration or link it separately.

# Lambda Event Source Mapping - triggers the thin consumer Lambda from SQS queue
resource "aws_lambda_event_source_mapping" "stripe_metadata_updates_consumer" {
  event_source_arn  = aws_sqs_queue.stripe_metadata_updates.arn
  function_name     = aws_lambda_function.sqs_thin_consumer.function_name
  batch_size        = 1  # Process one message at a time

  # Enable partial batch response - failed messages return to queue for retry
  function_response_types = ["ReportBatchItemFailures"]

  # Optional: Add a filter policy if you want to filter messages
  # filter_criteria {
  #   filter {
  #     pattern = jsonencode({ body = { product_code = ["MDI", "MEI", "MFI", "MSI"] } })
  #   }
  # }
}

# Optional: CloudWatch alarm to monitor DLQ for failed messages
resource "aws_cloudwatch_metric_alarm" "stripe_metadata_dlq_not_empty" {
  alarm_name          = "newsletters-stripe-metadata-dlq-not-empty"
  comparison_operator = "GreaterThanOrEqualToThreshold"
  evaluation_periods  = 1
  metric_name         = "ApproximateNumberOfMessagesVisible"
  namespace           = "AWS/SQS"
  period              = 300 # 5 minutes
  statistic           = "Average"
  threshold           = 1
  alarm_description   = "Alert when Stripe metadata DLQ has failed messages"
  treat_missing_data  = "notBreaching"

  dimensions = {
    QueueName = aws_sqs_queue.stripe_metadata_updates_dlq.name
  }
}

# Optional: CloudWatch alarm to monitor queue processing delay
resource "aws_cloudwatch_metric_alarm" "stripe_metadata_queue_delay" {
  alarm_name          = "newsletters-stripe-metadata-queue-delay"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 2
  metric_name         = "ApproximateAgeOfOldestMessage"
  namespace           = "AWS/SQS"
  period              = 300 # 5 minutes
  statistic           = "Maximum"
  threshold           = 300 # Alert if messages older than 5 minutes
  alarm_description   = "Alert when Stripe metadata updates are delayed"
  treat_missing_data  = "notBreaching"

  dimensions = {
    QueueName = aws_sqs_queue.stripe_metadata_updates.name
  }
}
