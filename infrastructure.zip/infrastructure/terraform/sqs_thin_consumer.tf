# Thin SQS consumer Lambda
# Bridges the SQS Event Source Mapping event format to the existing
# ASP.NET Core API Gateway endpoint (POST /process-metadata-updates).

# ---------------------------------------------------------------------------
# Package the Python handler into a zip Terraform can deploy
# ---------------------------------------------------------------------------
data "archive_file" "sqs_thin_consumer" {
  type        = "zip"
  source_file = "${path.module}/../sqs-consumer-lambda/handler.py"
  output_path = "${path.module}/../sqs-consumer-lambda/handler.zip"
}

# ---------------------------------------------------------------------------
# IAM role assumed by the thin Lambda at runtime
# ---------------------------------------------------------------------------
resource "aws_iam_role" "sqs_thin_consumer" {
  name = "newsletters-sqs-thin-consumer-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect    = "Allow"
        Principal = { Service = "lambda.amazonaws.com" }
        Action    = "sts:AssumeRole"
      }
    ]
  })

  tags = {
    Name        = "newsletters-sqs-thin-consumer-role"
    Environment = var.environment
    Project     = "Newsletters"
  }
}

# ---------------------------------------------------------------------------
# IAM inline policy: SQS read/delete + CloudWatch logs
# ---------------------------------------------------------------------------
resource "aws_iam_role_policy" "sqs_thin_consumer" {
  name = "newsletters-sqs-thin-consumer-policy"
  role = aws_iam_role.sqs_thin_consumer.name   # role NAME (not ARN)

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "SQSConsumeMessages"
        Effect = "Allow"
        Action = [
          "sqs:ReceiveMessage",
          "sqs:DeleteMessage",
          "sqs:GetQueueAttributes",
          "sqs:ChangeMessageVisibility"
        ]
        Resource = [
          aws_sqs_queue.stripe_metadata_updates.arn,
          aws_sqs_queue.stripe_metadata_updates_dlq.arn
        ]
      },
      {
        Sid    = "CloudWatchLogs"
        Effect = "Allow"
        Action = [
          "logs:CreateLogGroup",
          "logs:CreateLogStream",
          "logs:PutLogEvents"
        ]
        Resource = "arn:aws:logs:*:*:*"
      }
    ]
  })
}

# ---------------------------------------------------------------------------
# The thin Lambda function
# ---------------------------------------------------------------------------
resource "aws_lambda_function" "sqs_thin_consumer" {
  function_name    = "newsletters-stripe-metadata-sqs-consumer"
  role             = aws_iam_role.sqs_thin_consumer.arn
  filename         = data.archive_file.sqs_thin_consumer.output_path
  source_code_hash = data.archive_file.sqs_thin_consumer.output_base64sha256
  handler          = "handler.handler"
  runtime          = "python3.12"
  timeout          = 30
  memory_size      = 256

  # Rate-limit Stripe API calls: at most 2 concurrent executions
  reserved_concurrent_executions = var.consumer_lambda_reserved_concurrency

  environment {
    variables = {
      API_GATEWAY_URL = var.consumer_api_gateway_url
      API_GATEWAY_KEY = var.consumer_api_gateway_key
    }
  }

  tags = {
    Name        = "newsletters-stripe-metadata-sqs-consumer"
    Environment = var.environment
    Project     = "Newsletters"
  }

  depends_on = [aws_iam_role_policy.sqs_thin_consumer]
}

# ---------------------------------------------------------------------------
# CloudWatch log group (7-day retention)
# ---------------------------------------------------------------------------
resource "aws_cloudwatch_log_group" "sqs_thin_consumer" {
  name              = "/aws/lambda/${aws_lambda_function.sqs_thin_consumer.function_name}"
  retention_in_days = 7

  tags = {
    Name    = "newsletters-sqs-thin-consumer-logs"
    Project = "Newsletters"
  }
}
