variable "environment" {
  description = "Environment name (dev, staging, prod)"
  type        = string
  default     = "dev"
}

variable "stripe_metadata_update_queue_visibility_timeout" {
  description = "Visibility timeout in seconds for Stripe metadata update queue"
  type        = number
  default     = 60
}

variable "stripe_metadata_update_queue_max_receive_count" {
  description = "Maximum number of times a message can be received before being sent to DLQ"
  type        = number
  default     = 3
}

variable "stripe_metadata_update_queue_retention_seconds" {
  description = "Message retention period in seconds for Stripe metadata update queue"
  type        = number
  default     = 345600 # 4 days
}

variable "stripe_metadata_dlq_retention_seconds" {
  description = "Message retention period in seconds for DLQ"
  type        = number
  default     = 1209600 # 14 days
}

# ---------------------------------------------------------------------------
# Thin consumer Lambda — API Gateway forwarding
# ---------------------------------------------------------------------------

variable "consumer_api_gateway_url" {
  description = "Full URL of the ASP.NET Core API Gateway endpoint that processes SQS batches (POST /process-metadata-updates)"
  type        = string
}

variable "consumer_api_gateway_key" {
  description = "Optional API key sent as x-api-key header when calling consumer_api_gateway_url. Leave empty if the endpoint has no key requirement."
  type        = string
  default     = ""
  sensitive   = true
}

