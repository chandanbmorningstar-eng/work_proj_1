environment = "non-prod"

consumer_lambda_function_name      = "NewslettersNonVPC-Newsletters-7OSL0xcbxm5e"
consumer_lambda_reserved_concurrency = 2
consumer_lambda_timeout            = 30
consumer_lambda_memory_size        = 512
consumer_lambda_role_arn           = "rpmn-non-prod"

# URL of the existing API Gateway endpoint (POST /process-metadata-updates)
consumer_api_gateway_url = "https://d0riyx9c5e.execute-api.us-east-1.amazonaws.com/Dev/process-metadata-updates"

stripe_metadata_update_queue_visibility_timeout = 900
stripe_metadata_update_queue_max_receive_count = 3
stripe_metadata_update_queue_retention_seconds = 345600  # 4 days
stripe_metadata_dlq_retention_seconds          = 1209600 # 14 days
