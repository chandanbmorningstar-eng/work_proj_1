package com.morningstar.newsLettersApi.common;

public interface Endpoints {
    String AnalystReport = "/analyst-report-and-note";
    String MSITortoiseHarePortfolioAndWatchlist = "/portfolios-watchlists";
    String MDIDividendPortfolioBellwethers = "/portfolios-watchlists";
    String MFIFund500CategoryGroupList = "/m500-category-groupList";
    String MFIM500Funds = "/m500-funds";
    String MFIFundSpySelector = "/fund-spy-selector";
    String MFIFund500CategoryDetails = "/m500-category-groups ";
    String ETFEquityWatchlist = "/equity-watchlist";
    String ETFBondWatchlist = "/bond-watchlist";
    String ETFModelPortfolio = "/model-portfolios-details";
    String ETFPortfolioPerformance = "/model-portfolios-performance";
    String ETFCategoryOverview = "/category-overview";
    String ResearchReport = "/research-report";
    String LatestIssues = "/api/NewsLetters/GetLatestIssues";
    String HomePageCoverImages = "/api/NewsLetters/HomePageCoverImages";
}