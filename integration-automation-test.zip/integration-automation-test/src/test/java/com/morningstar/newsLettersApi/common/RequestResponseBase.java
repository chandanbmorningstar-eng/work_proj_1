package com.morningstar.newsLettersApi.common;

import com.morningstar.framework.report.FrameworkServices;
import com.morningstar.newsLettersApi.utility.FunctionalUtilities;
import com.morningstar.newsLettersApi.utility.TestDataUtility;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.BeforeEach;

import static io.restassured.RestAssured.given;

public abstract class RequestResponseBase {
    FrameworkServices frameworkLogger = new FrameworkServices(RequestResponseBase.class);
    private String xApiKeyValue = null;
    private String baseUrl = null;
    private static String environment = "env";

    @BeforeEach
    public void init()   {
        baseUrl = FunctionalUtilities.getBaseUrl();
    }

    // Thia Method writes the Response in proper manner
    public void responseLogger(Response response) {
        frameworkLogger.info("------------Response STARTS----------------");
        ((ValidatableResponse) response.then()).log().all();
        frameworkLogger.info("------------Response ENDS------------------");
    }

    //This Method is used for GET Call
    public Response getAndReturnAPI(RequestSpecification requestSpecification, String urlPath, int statusCode) {
        Response response = requestSpecification
                .relaxedHTTPSValidation()
                .log().all()
                .contentType(ContentType.JSON)
                .when()
                .get(baseUrl + urlPath)
                .then()
                .assertThat()
                .statusCode(statusCode)
                .extract()
                .response();
        responseLogger(response);
        return response;
    }

    /* This Method is used for POST Call which takes parameter as follows
     * urlPath : API EndPoint
     * jsonFileName : taking input as JSONFile from testData
     * statusCode : what should be the status code of API call
     * */
    public Response postWithJSONFileAndReturnAPI(String urlPath, String jsonFileName, int statusCode) {
        JSONObject jsonPayload = TestDataUtility.getJsonFileData(jsonFileName);

        Response response = given()
                .relaxedHTTPSValidation()
                .log().all()
                .contentType(ContentType.JSON)
                .when()
                .header("X-Api-Key", xApiKeyValue)
                .body(jsonPayload)
                .post(baseUrl + urlPath)
                .then()
                .assertThat()
                .statusCode(statusCode)
                .extract()
                .response();
        responseLogger(response);
        return response;
    }

    /* This Method is used for POST Call which takes parameter as follows
     * urlPath : API EndPoint
     * jsonPayload : taking input as JSONObject from testData
     * statusCode : what should be the status code of API call
     * */
    public Response postWithJSONObjectAndReturnAPI(String urlPath, JSONObject jsonPayload, int statusCode) {
        Response response = given()
                .relaxedHTTPSValidation()
                .log().all()
                .contentType(ContentType.JSON)
                .when()
                .body(jsonPayload)
                .post(baseUrl + urlPath)
                .then()
                .assertThat()
                .statusCode(statusCode)
                .extract()
                .response();
        responseLogger(response);
        return response;
    }

    //This method is used for DELETE call
    public Response deleteAndReturnAPI(RequestSpecification requestSpecification, String urlPath, int statusCode) {
        Response response = requestSpecification
                .relaxedHTTPSValidation()
                .log().all()
                .contentType(ContentType.JSON)
                .when()
                .delete(baseUrl + urlPath)
                .then()
                .assertThat()
                .statusCode(statusCode)
                .extract()
                .response();
        responseLogger(response);
        return response;
    }
}