package com.morningstar.newsLettersApi.config;

import lombok.Getter;
import lombok.Setter;

public final class AppSettings {
    @Getter
    @Setter
    private NewsLetterConfig newsLettersApi;
}