package com.morningstar.newsLettersApi.config;

import com.morningstar.newsLettersApi.utility.FunctionalUtilities;
import org.yaml.snakeyaml.Yaml;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;

public class ConfigurationManager {

    public static String getEnv() {
        return Optional.ofNullable(System.getProperty("env")).orElseGet(() -> Environment.env);
    }

    private static ConfigurationManager instance = new ConfigurationManager();

    private AppSettings appSettings;

    private ConfigurationManager() {
        Yaml yaml = new Yaml();
        Path path = Paths.get("src", "test", "resources", "config", FunctionalUtilities.getEnv().toUpperCase() + ".yaml");

        try (InputStream in = Files.newInputStream(path)) {
            appSettings = yaml.loadAs(in, AppSettings.class);
        } catch (IOException ie) {
            //TODO:Log exception.
            ie.printStackTrace();
            throw new ExceptionInInitializerError(ie);
        }
    }

    private static ConfigurationManager getInstance() {
        if (instance == null) {
            //synchronized block to remove overhead
            synchronized (ConfigurationManager.class) {
                if (instance == null) {
                    // if instance is null, initialize
                    instance = new ConfigurationManager();
                }
            }
        }
        return instance;
    }

    public static AppSettings getSettings() {
        return getInstance().appSettings;
    }
}
