package com.morningstar.newsLettersApi.config;

public interface Environment {

    String env = "STG";
}

