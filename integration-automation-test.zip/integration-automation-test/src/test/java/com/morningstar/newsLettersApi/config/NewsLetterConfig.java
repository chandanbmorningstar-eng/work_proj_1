package com.morningstar.newsLettersApi.config;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NewsLetterConfig {
    private String baseUrl;
    private String apiKey;
    private String region;
}
