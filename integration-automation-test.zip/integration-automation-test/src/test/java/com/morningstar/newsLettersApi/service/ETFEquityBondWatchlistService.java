package com.morningstar.newsLettersApi.service;

import com.morningstar.framework.SoftAssert;
import com.morningstar.framework.report.FrameworkServices;
import com.morningstar.newsLettersApi.utility.TestDataUtility;
import org.junit.Assert;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class ETFEquityBondWatchlistService extends TestDataUtility {

    public static FrameworkServices frameworkLogger = new FrameworkServices(ETFEquityBondWatchlistService.class);
    public static SoftAssert softAssert = new SoftAssert();

    /*
     * This method verify the response body for EquityBondWatchlist
     * @equityBondGroup - Contains Watchlist list
     * @watchListName - it could be Equity or BondWatchlist
     * */
    static public void verifyEquityBondWatchlist(List<Map> equityBondGroup, String watchListName) throws FileNotFoundException {
        if (equityBondGroup.size() > 0) {
            ArrayList<String> equityBondListObject = new ArrayList();
            equityBondListObject.addAll(getEquityBondWatchlistObject(watchListName));
            for (int watchListIndex = 0; watchListIndex < equityBondGroup.size(); watchListIndex++) {
                LinkedHashMap<String, String> watchListObject = (LinkedHashMap<String, String>) equityBondGroup.get(watchListIndex);
                equityBondListObject.parallelStream().forEach(holding -> softAssert.
                        assertNotNull(watchListObject.get(holding), watchListObject.get("Ticker")));
            }
        } else {
            frameworkLogger.error("equityBondGroup List is Empty");
        }
        softAssert.assertAll();
    }

    /*
     * This method verify modelPortfolioDetails response
     * @modelPortfolioDetails - it contains modelPortfolioDetails values
     * */
    static public void verifyModelPortfolio(List<Map> modelPortfolioDetails) {
        if (modelPortfolioDetails.size() > 0) {
            for (int portfolioIndex = 0; portfolioIndex < modelPortfolioDetails.size(); portfolioIndex++) {
                LinkedHashMap<String, String> portfolioObject = (LinkedHashMap<String, String>) modelPortfolioDetails
                        .get(portfolioIndex);
                ArrayList<String> portfolioList = new ArrayList(Arrays.asList("PortfolioID", "PortfolioName",
                        "PerformanceId", "Name", "SecId", "Ticker", "MorningstarCategory", "MorningstarRating",
                        "InceptionDate", "PortfolioHoldingDate", "ExpenseRatio", "Target", "AssetAllocation",
                        "Beta", "Correlation", "FundYield", "MorningstarAnalystRating"));
                portfolioList.parallelStream().forEach(fund -> softAssert.assertNotNull(portfolioObject.get(fund), portfolioObject.get("Ticker")));
            }
        } else {
            frameworkLogger.error("modelPortfolio Details is empty");
        }
        softAssert.assertAll();
    }

    /*
     * This method verify PortfolioPerformance response
     * @modelPortfolioDetails - it contains portfolioPerformance values
     * */
    static public void verifyPortfolioPerformance(List<Map> portfolioPerformance) {
        if (portfolioPerformance.size() > 0) {
            for (int portfolioIndex = 0; portfolioIndex < portfolioPerformance.size(); portfolioIndex++) {
                LinkedHashMap<String, String> portfolioObject = (LinkedHashMap<String, String>) portfolioPerformance
                        .get(portfolioIndex);
                ArrayList<String> portfolioList = new ArrayList(Arrays.asList("PortfolioID", "PortfolioName",
                        "Return1Yr", "Return3Yr", "Return5Yr", "Return10Yr", "SharpeRatio1Yr", "SharpeRatio3Yr",
                        "SharpeRatio5Yr", "SharpeRatio10Yr", "StdDev1Yr", "StdDev3Yr", "StdDev5Yr", "StdDev10Yr"));
                portfolioList.parallelStream().forEach(fund -> softAssert.assertNotNull(portfolioObject.get(fund),
                        portfolioObject.get("PortfolioName")));
            }
        } else {
            frameworkLogger.error("portfolioPerformance is empty");
        }
        softAssert.assertAll();
    }

    /*
     * This method verify AnalysisReport response
     * @analysisResponse - it contains analysisResponse values
     * @secId - it contains secId of ticker
     * */
    static public void verifyAnalysisReport(Map analysisResponse, String secId) {
        LinkedHashMap<String, String> analysisObject = (LinkedHashMap<String, String>) analysisResponse;
        ArrayList<String> analysisReportList = new ArrayList(Arrays.asList("DocumentID", "ColID", "Title",
                "Date", "Time", "Author", "Email", "Sustainability_ETF", "FundamentalView_ETF",
                "ETFFees_ETF", "PortfolioConstruction_ETF"));
        analysisReportList.parallelStream().forEach(report -> softAssert.assertNotNull(analysisObject.get(report),
                "Getting Null for secID = " + secId));
    }

    /*
     * This method returns Equity or BondWatchlist Object
     * */
    static ArrayList<String> getEquityBondWatchlistObject(String fileName) throws FileNotFoundException {
        String newsLetter = "ETF";
        Scanner scanner = new Scanner(new File(TestDataUtility.getFilePath(fileName, newsLetter)));

        ArrayList<String> equityBondListObject = new ArrayList<>();
        while (scanner.hasNext()) {
            equityBondListObject.add(scanner.next().trim());
        }
        scanner.close();
        return equityBondListObject;
    }


    /*
     * This method verify issues CTA response and compare date like 1st date should be greater than other
     * @listOfIssues - it contains listOfIssues values
     * */
    static public void verifyIssuesCTA(List<Map> listOfIssues) throws ParseException {
        if (listOfIssues.size() > 0) {
            ArrayList<String> holdingIssuesList = new ArrayList(Arrays.asList("IssueID", "Product", "Title",
                    "Author", "IssueDate", "Description", "FileName", "Note", "PublishDate", "Volume",
                    "VolumeNum", "Status", "LastModified", "LastModifiedBy", "Deck", "ImageId"));

            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
            for (int i = 0; i < listOfIssues.size() - 1; i++) {
                if (!(simpleDateFormat.parse(listOfIssues.get(i).get("IssueDate").toString())
                        .after(simpleDateFormat.parse(listOfIssues.get(i + 1).get("IssueDate").toString())))) {
                    Assert.fail("Issue title = " + listOfIssues.get(i).get("Title") + " date = " +
                            listOfIssues.get(i).get("IssueDate").toString() + "  is less than issue title = " +
                            listOfIssues.get(i + 1).get("Title") + " date = " + listOfIssues.get(i + 1)
                            .get("IssueDate").toString());
                }
            }

            for (int issueIndex = 0; issueIndex < listOfIssues.size(); issueIndex++) {
                Map issuesGroupObject = listOfIssues.get(issueIndex);
                holdingIssuesList.parallelStream().forEach(issue -> softAssert.
                        assertNotNull(issuesGroupObject.get(issue)));
            }

        } else {
            frameworkLogger.error("listOfIssues List is Empty");
        }
        softAssert.assertAll();
    }
}