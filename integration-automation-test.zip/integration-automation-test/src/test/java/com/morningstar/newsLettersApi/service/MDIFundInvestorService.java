package com.morningstar.newsLettersApi.service;

import com.morningstar.framework.SoftAssert;
import com.morningstar.framework.report.FrameworkServices;
import com.morningstar.newsLettersApi.common.Endpoints;
import com.morningstar.newsLettersApi.common.RequestResponseBase;
import io.restassured.specification.RequestSpecification;
import org.apache.http.HttpStatus;
import org.junit.Assert;

import java.util.*;

import static io.restassured.RestAssured.given;

public class MDIFundInvestorService extends RequestResponseBase {

    static FrameworkServices frameworkLogger = new FrameworkServices(MDIFundInvestorService.class);
    static SoftAssert softAssert = new SoftAssert();

    /*
     * This method verify Portfolio and Bellwethers response
     * @holdings - it contains portfolio and Bellwether holding details
     * @isIncomeBellwethers - if its true, then we are adding extra field
     * */
    static protected void verifyMDIPortfolioBellwethersResponseBody(List<Map> holdings, boolean isIncomeBellwethers) {
        if (holdings.size() > 0) {
            ArrayList<String> holdingGroupList = new ArrayList(Arrays.asList("SecId", "Symbol", "StandardName", "StockStarRating",
                    "SecurityType", "FairValue", "ForwardDividendYield", "LastPrice", "StockRiskRating", "ConsiderBuy",
                    "AnalysisDate", "EconomicMoat", "Shares", "Weight", "ConsiderSell", "MarketValue",
                    "PriceOverFairValue", "DividendRate", "DividendBuy", "AnnualIncome", "CacheDate", "ExchangeId",
                    "ClosePrice", "PrevPriceOverFairValue", "PrevMarketValue"));
            if (isIncomeBellwethers) {
                ArrayList<String> incomeBellwethers = new ArrayList(Arrays.asList("Sector", "Category", "BestIdea", "StrategicAppeal"));
                holdingGroupList.addAll(incomeBellwethers);
            }
            for (int holdingIndex = 0; holdingIndex < holdings.size(); holdingIndex++) {
                Map holdingGroupObject = holdings.get(holdingIndex);
                holdingGroupList.parallelStream().forEach(holding -> softAssert.assertNotNull(holdingGroupObject.get(holding)));
            }
        } else {
            frameworkLogger.error("holdings List is Empty");
        }
        softAssert.assertAll();
    }

    /*
     * This method verify details of each researchRecords group
     * @researchRecords - it contains research records overview details
     * */
    private void verifyResearchRecords(List<Map> researchRecords) {
        if (researchRecords.size() > 0) {
            for (int categoryGroupIndex = 0; categoryGroupIndex < researchRecords.size(); categoryGroupIndex++) {
                Map categoryObject = researchRecords.get(categoryGroupIndex);
                ArrayList<String> categoryList = new ArrayList(Arrays.asList("SecId", "DocumentID", "ColID", "Title", "DateString", "Date", "Time", "Author"));
                categoryList.parallelStream().forEach(category -> softAssert.assertNotNull(categoryObject.get(category)));
            }
        } else {
            frameworkLogger.error("researchRecords List is Empty");
        }
        softAssert.assertAll();
    }

    /*
     * This method calls api to get tickers, takes SecId and calls function verifyResearchRecords
     * @queryParameters - contains query params for specific Portfolio
     * */
    protected void researchRecords(Map<String, String> queryParameters) {
        List<Map> portfolioResponse = getAndReturnAPI(given().request().queryParams(queryParameters),
                Endpoints.MDIDividendPortfolioBellwethers, HttpStatus.SC_OK).jsonPath().get();

        Assert.assertNotNull("portfolio is null", portfolioResponse);
        Assert.assertTrue("portfolio is empty", portfolioResponse.size() > 0);

        StringBuffer secId = new StringBuffer("");
        for (int categoryIndex = 0; categoryIndex < portfolioResponse.size(); categoryIndex++) {
            if (categoryIndex == portfolioResponse.size() - 1) {
                secId.append(portfolioResponse.get(categoryIndex).get("SecId").toString().trim());
            } else {
                secId.append(portfolioResponse.get(categoryIndex).get("SecId").toString().trim() + ",");
            }
        }
        RequestSpecification requestSpecificationReport = given().request().queryParams("SectionId", secId.toString());
        List<Map> researchResponse = getAndReturnAPI(requestSpecificationReport, Endpoints.ResearchReport, HttpStatus.SC_OK).jsonPath().get();

        Assert.assertNotNull("research response is null", researchResponse);
        Assert.assertTrue("research response size is more than 10", researchResponse.size() <= 10);
        verifyResearchRecords(researchResponse);
    }
}