package com.morningstar.newsLettersApi.service;

import com.morningstar.framework.SoftAssert;
import com.morningstar.framework.report.FrameworkServices;

import java.util.*;

public class MFIFundInvestorService {

    static FrameworkServices frameworkLogger = new FrameworkServices(MFIFundInvestorService.class);

    /*
     * This method verify details of each category group
     * @categoryGroup - it contains category details
     * @softAssert - passing the soft assert object
     * */
    static public void verifyCategoryGroupDetails(List<Map> categoryGroup, SoftAssert softAssert) {
        if (categoryGroup.size() > 0) {
            for (int categoryGroupIndex = 0; categoryGroupIndex < categoryGroup.size(); categoryGroupIndex++) {
                Map categoryGroupObject = categoryGroup.get(categoryGroupIndex);
                ArrayList<String> categoryGroupObjectList = new ArrayList(Arrays.asList("GroupName",
                        "GroupLevel", "ShortCode", "AVG_DailyReturnYTD", "AVG_DailyReturn4Week",
                        "AVG_DailyReturn156Week", "AVG_DailyReturn260Week", "AVG_MonthlyReturn10Year",
                        "AVG_MonthlyReturn15Year"));
                categoryGroupObjectList.parallelStream().forEach(holding -> softAssert.assertNotNull(categoryGroupObject.get(holding)));
            }
        } else {
            frameworkLogger.error("categoryGroup List is Empty");
        }
        softAssert.assertAll();
    }

    /*
     * This method verify response of CategoryName and ShortCode
     * @categoryGroup - it contains values for CategoryName and ShortCode
     * @softAssert - passing the soft assert object
     * */
    static public void verifyCategoryGroupResponse(List<Map> categoryGroup, SoftAssert softAssert) {
        if (categoryGroup.size() > 1) {
            for (int categoryIndex = 0; categoryIndex < categoryGroup.size(); categoryIndex++) {
                Map categoryGroupObject = categoryGroup.get(categoryIndex);
                ArrayList<String> categoryGroupList = new ArrayList(Arrays.asList("CategoryName", "ShortCode"));
                categoryGroupList.parallelStream().forEach(holding -> softAssert.assertNotNull(categoryGroupObject.get(holding)));
            }
        } else {
            frameworkLogger.error("Category Group List should contain more than one element");
        }
        softAssert.assertAll();
    }

    /*
     * This method verify fund details response of CategoryName
     * @fundDetails - it contains fundDetails values
     * @softAssert - passing the soft assert object
     * */
    static public void verifyFundDetails(List<Map> fundDetails, SoftAssert softAssert) {
        if (fundDetails.size() > 0) {
            for (int fundIndex = 0; fundIndex < fundDetails.size(); fundIndex++) {
                Map fundDetailsObject = fundDetails.get(fundIndex);
                ArrayList<String> fundList = new ArrayList(Arrays.asList("ShortName", "Symbol"
                        , "AnalystRating", "RatingOverall", "EPUsedForOverallRating", "DailyReturn4Week",
                        "DailyReturnYTD", "DailyReturn156Week", "DailyReturn260Week", "MonthlyReturn10Year"
                        , "MonthlyReturn15Year", "DailyReturn4WeekCategoryPercentileRank",
                        "DailyReturnYTDCategoryPercentileRank", "DailyReturn156WeekCategoryPercentileRank"
                        , "DailyReturn260WeekCategoryPercentileRank", "MonthlyReturn10YearCategoryPercentileRank",
                        "MonthlyReturn15YearCategoryPercentileRank", "InvestorReturn3Year", "InvestorReturn5Year",
                        "InvestorReturn10Year", "InvestorReturn15Year", "TaxCostRatio5Year", "Worst3Month",
                        "ManagerInvestment", "Beta3Year"
                ));
                fundList.parallelStream().forEach(fund -> softAssert.assertNotNull(fundDetailsObject.get(fund)));
            }
        } else {
            frameworkLogger.error("fund Details is empty");
        }
    }


    /*
     * This method verify  fund Spy Selector response of tickers
     * @fundSpyDetails - it contains fund spy Details values
     * @softAssert - passing the soft assert object
     * */
    static public void verifyFundSpySelector(List<Map> fundSpyDetails, SoftAssert softAssert) {
        if (fundSpyDetails.size() > 0) {
            for (int fundSpyIndex = 0; fundSpyIndex < fundSpyDetails.size(); fundSpyIndex++) {
                Map fundDetailsObject = fundSpyDetails.get(fundSpyIndex);
                ArrayList<String> fundSpyList = new ArrayList(Arrays.asList("FundName", "FundTicker"
                        , "MorningstarRating", "Category", "Managers", "IndexFund", "ExpenseRatio",
                        "Risk", "ManagerStartDate", "FundReturn", "BenchmarkReturn", "ManagerRange",
                        "People", "Parent", "ManagerRange_Test", "Parent_PillarTest",
                        "People_PillarTest", "Risk_Test", "ExpenseRatio_Test", "ManagerPerformance_Test"
                ));
                fundSpyList.parallelStream().forEach(fundSpy -> softAssert.assertNotNull(fundDetailsObject.get(fundSpy)));
            }
        } else {
            frameworkLogger.error("fund Spy Details is empty");
        }
    }

    /*
     * This method verify  fund total 500 tickers, and unique tickers
     * @duplicateTickersList - it contains fund spy Details values
     * @perCategoryTickers - it contains per Category Ticker
     * @allTickerCount - it contains total TickerCount
     * @softAssert - passing the soft assert object
     * */
    static public void verifyTotalDuplicateTickers(Set<String> duplicateTickersList, Map<String, List<String>> perCategoryTickers, int allTickerCount, SoftAssert softAssert) {
        String duplicateTickers, categoryName;
        Iterator<String> duplicateTickerItr = duplicateTickersList.iterator();
        String category = "";
        while (duplicateTickerItr.hasNext()) {
            duplicateTickers = duplicateTickerItr.next();
            for (Map.Entry<String, List<String>> categoryTickersMap : perCategoryTickers.entrySet()) {
                categoryName = categoryTickersMap.getKey();
                List<String> tickersList = categoryTickersMap.getValue();
                if (tickersList.contains(duplicateTickers)) {
                    category = category + categoryName + " ";
                }
            }
            softAssert.fail("Category = " + category + " has duplicate ticker = " + duplicateTickers);
            category = "";
        }
        softAssert.assertEquals(allTickerCount, 500, "Tickers total are not 500");
        softAssert.assertAll();
    }

    /*
     * This method verify details of each categories group
     * @categories - it contains categories overview
     * @softAssert - passing the soft assert object
     * */
    static public void verifyCategoryOverview(List<Map> categories, SoftAssert softAssert) {
        if (categories.size() > 0) {
            for (int categoryGroupIndex = 0; categoryGroupIndex < categories.size(); categoryGroupIndex++) {
                Map categoryObject = categories.get(categoryGroupIndex);
                ArrayList<String> categoryList = new ArrayList(Arrays.asList("Id", "Name"));
                categoryList.parallelStream().forEach(category -> softAssert.assertNotNull(categoryObject.get(category)));
            }
        } else {
            frameworkLogger.error("categories List is Empty");
        }
        softAssert.assertAll();
    }

    /*
     * This method verify details of each categoriesDetails group
     * @categoryName - it contains category name
     * @categoriesDetails - it contains categoriesDetails overview
     * @softAssert - passing the soft assert object
     * */
    static public void verifyCategoryOverviewDetails(String categoryName, List<Map> categoriesDetails, SoftAssert softAssert) {
        if (categoriesDetails.size() > 0) {
            for (int categoryGroupIndex = 0; categoryGroupIndex < categoriesDetails.size(); categoryGroupIndex++) {
                Map categoryObject = categoriesDetails.get(categoryGroupIndex);
                ArrayList<String> categoryList = new ArrayList(Arrays.asList("Author", "Content", "PublishedDate", "PublishedTime", "DocumentID", "Emails", "Title"));
                categoryList.parallelStream().forEach(category -> softAssert.assertNotNull(categoryObject.get(category), "Getting null for category Name = " + categoryName));
            }
        } else {
            frameworkLogger.error("categoriesDetails List is Empty");
        }
    }
}