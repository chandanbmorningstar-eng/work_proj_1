package com.morningstar.newsLettersApi.service;

import com.morningstar.framework.SoftAssert;
import com.morningstar.framework.report.FrameworkServices;
import com.morningstar.newsLettersApi.common.Endpoints;
import com.morningstar.newsLettersApi.common.RequestResponseBase;
import io.restassured.specification.RequestSpecification;
import org.apache.http.HttpStatus;
import org.junit.Assert;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static io.restassured.RestAssured.given;

public class MSIFundInvestorService extends RequestResponseBase {

    static FrameworkServices frameworkLogger = new FrameworkServices(MSIFundInvestorService.class);
    static SoftAssert softAssert = new SoftAssert();

    /*
     * This method verify Portfolio and Watchlist response
     * @holdings - it contains portfolio and Watchlist holding details
     * @isTortoiseAndHareWatchlist - if its true, then we are adding extra field
     * */
    static public void verifyMSIPortfolioWatchlistResponseBody(List<Map> holdings, boolean isTortoiseAndHareWatchlist) {
        if (holdings.size() > 0) {
            ArrayList<String> holdingGroupList = new ArrayList(Arrays.asList("SecurityType", "StandardName", "Symbol",
                    "SecId", "EconomicMoat", "FairValue", "LastPrice", "PFV", "PriceChangePct", "Quantity",
                    "RiskRating", "StarRating", "Weight", "FidGrade", "AnalysisDate", "SectorName", "MoatTrend"));
            if (isTortoiseAndHareWatchlist) {
                ArrayList<String> tortoiseAndHareWatchList = new ArrayList(Arrays.asList("PortIndicator", "Stewardship",
                        "Risk", "LastClose", "ForwardPE", "ForwardDividendYield"));
                holdingGroupList.addAll(tortoiseAndHareWatchList);
            }
            for (int holdingIndex = 0; holdingIndex < holdings.size(); holdingIndex++) {
                Map holdingGroupObject = holdings.get(holdingIndex);
                holdingGroupList.parallelStream().forEach(holding -> softAssert.assertNotNull(holdingGroupObject.get(holding), "holding name = " + holding));
            }
        } else {
            frameworkLogger.error("holdings List is Empty");
        }
        softAssert.assertAll();
    }

    /*
     * This method verify Analysis Report
     * @reportDetails - it contains holding details
     * @secID - it contains holding ID
     * @softAssert - passing the soft assert object
     * */
    static public void verifyMSIAnalysisReport(Map reportDetails, String secID, SoftAssert softAssert) {
        if (!reportDetails.isEmpty()) {
            ArrayList<String> reportList = new ArrayList(Arrays.asList("DocumentID", "ColID", "Title",
                    "Date", "Time", "Author", "Email", "Thesis", "Valuation", "Risk",
                    "Mgmt", "Profile", "Moat", "AnalystNote_Date", "AnalystNote_Time", "AnalystNote_Content", "FinancialHealth_MDI"));

            Map holdingGroupObject = reportDetails;
            reportList.parallelStream().forEach(holding -> softAssert.assertNotNull(holdingGroupObject.get(holding), "Some Fields of AnalysisReport is null for secId = " + secID));
        } else {
            frameworkLogger.error("reportDetails List is Empty");
        }
    }

    /*
     * This method calls verify Research Records
     * @researchRecords - contains research records
     * */
    private void verifyResearchRecords(List<Map> researchRecords) {
        if (researchRecords.size() > 0) {
            for (int categoryGroupIndex = 0; categoryGroupIndex < researchRecords.size(); categoryGroupIndex++) {
                Map categoryObject = researchRecords.get(categoryGroupIndex);
                ArrayList<String> categoryList = new ArrayList(Arrays.asList("SecId", "DocumentID", "ColID", "Title", "DateString", "Date", "Time", "Author"));
                categoryList.parallelStream().forEach(category -> softAssert.assertNotNull(categoryObject.get(category)));
            }
        } else {
            frameworkLogger.error("researchRecords List is Empty");
        }
        softAssert.assertAll();
    }

    /*
     * This method calls api to get tickers, takes SecId and calls function verifyResearchRecords
     * @queryParameters - contains query params for specific Portfolio
     * */
    protected void researchRecords(Map<String, String> queryParameters) {
        List<Map> portfolioResponse = getAndReturnAPI(given().request().queryParams(queryParameters),
                Endpoints.MDIDividendPortfolioBellwethers, HttpStatus.SC_OK).jsonPath().get();

        Assert.assertNotNull("portfolio is null", portfolioResponse);
        Assert.assertTrue("portfolio is empty", portfolioResponse.size() > 0);

        StringBuffer secId = new StringBuffer("");
        for (int categoryIndex = 0; categoryIndex < portfolioResponse.size(); categoryIndex++) {
            if (categoryIndex == portfolioResponse.size() - 1) {
                secId.append(portfolioResponse.get(categoryIndex).get("SecId").toString().trim());
            } else {
                secId.append(portfolioResponse.get(categoryIndex).get("SecId").toString().trim() + ",");
            }
        }
        RequestSpecification requestSpecificationReport = given().request().queryParams("SectionId", secId.toString());
        List<Map> researchResponse = getAndReturnAPI(requestSpecificationReport, Endpoints.ResearchReport, HttpStatus.SC_OK).jsonPath().get();

        Assert.assertNotNull("research response is null", researchResponse);
        Assert.assertTrue("research response size is more than 10", researchResponse.size() <= 10);
        verifyResearchRecords(researchResponse);
    }

    /*
     * This method calls api to get tickers, takes SecId and verify analysis report
     * @queryParams - contains query params for specific PortfolioWatchlist
     * */
    protected void verifyMSIAnalysisReport(Map<String, String> queryParams, Map<String, String> analysisReportParams) {
        List<Map> holdingsResponse = getAndReturnAPI(given().request().queryParams(queryParams), Endpoints.MSITortoiseHarePortfolioAndWatchlist, HttpStatus.SC_OK).jsonPath().get();

        for (int holdingIndex = 0; holdingIndex < holdingsResponse.size(); holdingIndex++) {
            String secId = holdingsResponse.get(holdingIndex).get("SecId").toString();
            if (!secId.contains("CASH")) {
                analysisReportParams.put("SecId", secId);
                RequestSpecification analysisReport = given().request().queryParams(analysisReportParams);
                Map reportDetails = getAndReturnAPI(analysisReport, Endpoints.AnalystReport, HttpStatus.SC_OK).jsonPath().get();
                MSIFundInvestorService.verifyMSIAnalysisReport(reportDetails, secId, softAssert);
            }
        }
        softAssert.assertAll();
    }
}