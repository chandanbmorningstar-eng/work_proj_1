package com.morningstar.newsLettersApi.service;

import com.morningstar.framework.SoftAssert;
import com.morningstar.framework.report.FrameworkServices;
import org.junit.Assert;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class NewsLettersService {

    static FrameworkServices frameworkLogger = new FrameworkServices(MSIFundInvestorService.class);
    static SoftAssert softAssert = new SoftAssert();

    /*
     * This method verify image base 64 string response and fileContentList size should be five
     * @fileContentList - it contains List of  base64 string.
     * */
    static public void verifyMSIPortfolioWatchlistResponseBody(List<Map> fileContentList) {
        if (fileContentList.size() > 0) {
            Assert.assertTrue("fileContentList should be size 5", fileContentList.size() == 5);
            ArrayList<String> fileGroupList = new ArrayList(Arrays.asList("FileContent"));

            for (int fileContentIndex = 0; fileContentIndex < fileContentList.size(); fileContentIndex++) {
                Map fileContentObject = fileContentList.get(fileContentIndex);
                fileGroupList.parallelStream().forEach(holding -> softAssert.assertNotNull(fileContentObject.get(holding)));
            }
        } else {
            frameworkLogger.error("fileContentList List is Empty");
        }
        softAssert.assertAll();
    }
}