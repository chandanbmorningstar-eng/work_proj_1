package com.morningstar.newsLettersApi.tests;


import com.morningstar.newsLettersApi.common.Endpoints;
import com.morningstar.newsLettersApi.common.RequestResponseBase;
import com.morningstar.newsLettersApi.service.ETFEquityBondWatchlistService;
import com.morningstar.newsLettersApi.utility.TestDataUtility;
import io.restassured.specification.RequestSpecification;
import org.apache.commons.collections.map.HashedMap;
import org.apache.http.HttpStatus;
import org.junit.Assert;
import org.junit.jupiter.api.Test;

import java.io.FileNotFoundException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static io.restassured.RestAssured.given;

public class ETFEquityBondWatchlistTest extends RequestResponseBase {


    /**
     * This testcase verify the equityWatchList response
     */
    @Test
    public void testVerifyEquityWatchList() throws FileNotFoundException {
        String watchListName = "equityWatchlistData";
        List<Map> equityGroup = getAndReturnAPI(given().request(), Endpoints.ETFEquityWatchlist, HttpStatus.SC_OK).jsonPath().get();
        ETFEquityBondWatchlistService.verifyEquityBondWatchlist(equityGroup, watchListName);
    }

    /**
     * This testcase verify the equityWatchList Analysis Report
     */
    @Test
    public void testVerifyEquityWatchListAnalysisReport() {
        Map<String, String> queryParameters;
        String testDataFileName = "portfolioWatchlistParams";
        queryParameters = (Map) TestDataUtility.getHeadersAndQueryParam(testDataFileName);

        Map<String, String> reportQueryParameters = new HashMap<>();
        reportQueryParameters.put(queryParameters.get("ProductCodeValue"), queryParameters.get("EtfValue"));

        List<Map> equityGroup = getAndReturnAPI(given().request(), Endpoints.ETFEquityWatchlist, HttpStatus.SC_OK).jsonPath().get();

        Assert.assertNotNull("equity Group is null", equityGroup);
        Assert.assertTrue("equity Group List is empty", equityGroup.size() > 0);
        String secIdValue;

        for (int secIdIndex = 0; secIdIndex < equityGroup.size(); secIdIndex++) {
            secIdValue = equityGroup.get(secIdIndex).get(queryParameters.get("SecIdValue")).toString();
            reportQueryParameters.put(queryParameters.get("SecIdValue"), secIdValue);
            RequestSpecification analysisReport = given().request().queryParams(reportQueryParameters);
            Map equityResponse = getAndReturnAPI(analysisReport, Endpoints.AnalystReport, HttpStatus.SC_OK).jsonPath().get();
            ETFEquityBondWatchlistService.verifyAnalysisReport(equityResponse, secIdValue);
        }
        ETFEquityBondWatchlistService.softAssert.assertAll();
    }

    /**
     * This testcase verify the BondWatchList Analysis Report
     */
    @Test
    public void testVerifyBondWatchListAnalysisReport() {
        Map<String, String> queryParameters;
        String testDataFileName = "portfolioWatchlistParams";
        queryParameters = (Map) TestDataUtility.getHeadersAndQueryParam(testDataFileName);

        Map<String, String> reportQueryParameters = new HashMap<>();

        reportQueryParameters.put(queryParameters.get("ProductCodeValue"), queryParameters.get("EtfValue"));

        List<Map> bondGroup = getAndReturnAPI(given().request(), Endpoints.ETFBondWatchlist, HttpStatus.SC_OK).jsonPath().get();

        Assert.assertNotNull("bond Group is null", bondGroup);
        Assert.assertTrue("bond Group List is empty", bondGroup.size() > 0);
        String secIdValue;
        for (int secIdIndex = 0; secIdIndex < bondGroup.size(); secIdIndex++) {
            secIdValue = bondGroup.get(secIdIndex).get(queryParameters.get("SecIdValue")).toString();
            reportQueryParameters.put(queryParameters.get("SecIdValue"), secIdValue);
            RequestSpecification analysisReport = given().request().queryParams(reportQueryParameters);
            Map bondResponse = getAndReturnAPI(analysisReport, Endpoints.AnalystReport, HttpStatus.SC_OK).jsonPath().get();
            ETFEquityBondWatchlistService.verifyAnalysisReport(bondResponse, secIdValue);
        }
        ETFEquityBondWatchlistService.softAssert.assertAll();
    }

    /**
     * This testcase verify the BondWatchList response
     */
    @Test
    public void testVerifyBondWatchList() throws FileNotFoundException {
        String watchListName = "bondWatchlistData";
        List<Map> bondGroup = getAndReturnAPI(given().request(), Endpoints.ETFBondWatchlist, HttpStatus.SC_OK).jsonPath().get();
        ETFEquityBondWatchlistService.verifyEquityBondWatchlist(bondGroup, watchListName);
    }

    /**
     * This testcase verify the ModelPortfolio response
     */
    @Test
    public void testVerifyModelPortfolio() {
        List<Map> modelPortfolioGroup = getAndReturnAPI(given().request(), Endpoints.ETFModelPortfolio, HttpStatus.SC_OK).jsonPath().get();
        ETFEquityBondWatchlistService.verifyModelPortfolio(modelPortfolioGroup);
    }

    /**
     * This testcase verify the PortfolioPerformance response
     */
    @Test
    public void testVerifyPortfolioPerformance() {
        List<Map> portfolioGroup = getAndReturnAPI(given().request(), Endpoints.ETFPortfolioPerformance, HttpStatus.SC_OK).jsonPath().get();
        ETFEquityBondWatchlistService.verifyPortfolioPerformance(portfolioGroup);
    }

    /**
     * This testcase verify the IssueDescription response and date comparison
     */
    @Test
    public void testVerifyIssueDescription() throws ParseException {
        Map<String, String> queryParameters;
        String testDataFileName = "portfolioWatchlistParams";
        queryParameters = (Map) TestDataUtility.getHeadersAndQueryParam(testDataFileName);

        Map<String, String> issueParameters = new HashedMap();
        issueParameters.put(queryParameters.get("ProductCodeValue"), queryParameters.get("EtfValue"));
        issueParameters.put(queryParameters.get("NoOfRecordsValue"), queryParameters.get("NoOfRecordsInNumber"));
        List<Map> listOfIssues = getAndReturnAPI(given().request().queryParams(issueParameters), Endpoints.LatestIssues, HttpStatus.SC_OK).jsonPath().get();

        ETFEquityBondWatchlistService.verifyIssuesCTA(listOfIssues);
    }
}