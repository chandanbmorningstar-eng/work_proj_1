package com.morningstar.newsLettersApi.tests;

import com.morningstar.newsLettersApi.common.Endpoints;
import com.morningstar.newsLettersApi.service.MDIFundInvestorService;
import com.morningstar.newsLettersApi.utility.TestDataUtility;
import org.apache.commons.collections.map.HashedMap;
import org.apache.http.HttpStatus;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import java.util.List;
import java.util.Map;

import static io.restassured.RestAssured.given;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class MDIPortfolioBellwethersTest extends MDIFundInvestorService {

    Map<String, String> queryParameters;

    /*
     * setup method - retrieving the headers and query parameters and storing in params variable
     * */
    @BeforeAll
    public void setup() {
        String testDataFileName = "portfolioBellwethersMDIParams";
        queryParameters = (Map) TestDataUtility.getHeadersAndQueryParam(testDataFileName);
    }

    /**
     * This testcase verify the select portfolio holding response for each field with a null check with the help of an assertion
     */
    @Test
    public void testVerifyDividendSelectPortfolio() {
        Map<String, String> dividendSelectParameters = new HashedMap();
        dividendSelectParameters.put(queryParameters.get("UserIdHeader"), queryParameters.get("UserIdDividendSelectPortfolioValue"));
        dividendSelectParameters.put(queryParameters.get("ViewNoHeader"), queryParameters.get("ViewNoValue"));
        dividendSelectParameters.put(queryParameters.get("PortfolioIdHeader"), queryParameters.get("PortfolioIdDividendSelectPortfolioValue"));
        dividendSelectParameters.put(queryParameters.get("WatchListNameHeader"), queryParameters.get("WatchListNameDividendSelectPortfolioValue"));
        dividendSelectParameters.put(queryParameters.get("ProductCodeHeader"), queryParameters.get("MdiValue"));
        List<Map> portfolioResponse = getAndReturnAPI(given().request().queryParams(dividendSelectParameters),
                Endpoints.MDIDividendPortfolioBellwethers, HttpStatus.SC_OK).jsonPath().get();


        boolean isIncomeBellwethers = false;

        MDIFundInvestorService.verifyMDIPortfolioBellwethersResponseBody(portfolioResponse, isIncomeBellwethers);
    }


    /**
     * This testcase verify the Select deferred portfolio holding response for each field with a null check with the help of an assertion
     */
    @Test
    public void testVerifyDividendSelectDeferredPortfolio() {
        Map<String, String> deferredParameters = new HashedMap();
        deferredParameters.put(queryParameters.get("UserIdHeader"), queryParameters.get("UserIdDividendSelectDeferredPortfolioValue"));
        deferredParameters.put(queryParameters.get("ViewNoHeader"), queryParameters.get("ViewNoValue"));
        deferredParameters.put(queryParameters.get("PortfolioIdHeader"), queryParameters.get("PortfolioIdDividendSelectDeferredPortfolioValue"));
        deferredParameters.put(queryParameters.get("WatchListNameHeader"), queryParameters.get("WatchListNameDividendSelectDeferredPortfolioValue"));
        deferredParameters.put(queryParameters.get("ProductCodeHeader"), queryParameters.get("MdiValue"));

        List<Map> portfolioResponse = getAndReturnAPI(given().request().queryParams(deferredParameters),
                Endpoints.MDIDividendPortfolioBellwethers, HttpStatus.SC_OK).jsonPath().get();
        boolean isIncomeBellwethers = false;

        MDIFundInvestorService.verifyMDIPortfolioBellwethersResponseBody(portfolioResponse, isIncomeBellwethers);
    }

    /**
     * This testcase verify the Income bellwethers portfolio holding response for each field with a null check with the help of an assertion
     */
    @Test
    public void testVerifyIncomeBellwethers() {
        Map<String, String> incomeBellwethersParameters = new HashedMap();
        incomeBellwethersParameters.put(queryParameters.get("UserIdHeader"), queryParameters.get("UserIdIncomeBellwethersValue"));
        incomeBellwethersParameters.put(queryParameters.get("ViewNoHeader"), queryParameters.get("ViewNoValue"));
        incomeBellwethersParameters.put(queryParameters.get("PortfolioIdHeader"), queryParameters.get("PortfolioIdIncomeBellwethersValue"));
        incomeBellwethersParameters.put(queryParameters.get("WatchListNameHeader"), queryParameters.get("WatchListNameIncomeBellwethersValue"));
        incomeBellwethersParameters.put(queryParameters.get("ProductCodeHeader"), queryParameters.get("MdiValue"));

        List<Map> portfolioResponse = getAndReturnAPI(given().request().queryParams(incomeBellwethersParameters),
                Endpoints.MDIDividendPortfolioBellwethers, HttpStatus.SC_OK).jsonPath().get();
        boolean isIncomeBellwethers = true;

        MDIFundInvestorService.verifyMDIPortfolioBellwethersResponseBody(portfolioResponse, isIncomeBellwethers);
    }


    /**
     * This testcase verify the Dividend Select Research Record response and size should be less or equal 10.
     */
    @Test
    public void testVerifyDividendSelectResearchRecord() {
        Map<String, String> dividendSelectParameters = new HashedMap();
        dividendSelectParameters.put(queryParameters.get("UserIdHeader"), queryParameters.get("UserIdDividendSelectPortfolioValue"));
        dividendSelectParameters.put(queryParameters.get("ViewNoHeader"), queryParameters.get("ViewNoValue"));
        dividendSelectParameters.put(queryParameters.get("PortfolioIdHeader"), queryParameters.get("PortfolioIdDividendSelectPortfolioValue"));
        dividendSelectParameters.put(queryParameters.get("WatchListNameHeader"), queryParameters.get("WatchListNameDividendSelectPortfolioValue"));
        dividendSelectParameters.put(queryParameters.get("ProductCodeHeader"), queryParameters.get("MdiValue"));
        researchRecords(dividendSelectParameters);
    }

    /**
     * This testcase verify the select Deferred Research Record response and size should be less or equal 10.
     */
    @Test
    public void testVerifyDividendSelectDeferredResearchRecord() {
        Map<String, String> dividendDeferParameters = new HashedMap();
        dividendDeferParameters.put(queryParameters.get("UserIdHeader"), queryParameters.get("UserIdDividendSelectDeferredPortfolioValue"));
        dividendDeferParameters.put(queryParameters.get("ViewNoHeader"), queryParameters.get("ViewNoValue"));
        dividendDeferParameters.put(queryParameters.get("PortfolioIdHeader"), queryParameters.get("PortfolioIdDividendSelectDeferredPortfolioValue"));
        dividendDeferParameters.put(queryParameters.get("WatchListNameHeader"), queryParameters.get("WatchListNameDividendSelectDeferredPortfolioValue"));
        dividendDeferParameters.put(queryParameters.get("ProductCodeHeader"), queryParameters.get("MdiValue"));
        researchRecords(dividendDeferParameters);
    }

    /**
     * This testcase verify the select Income Bellwethers Record response and size should be less or equal 10.
     */
    @Test
    public void testVerifyIncomeBellwethersResearchRecord() {
        Map<String, String> incomeBellwethersParameters = new HashedMap();
        incomeBellwethersParameters.put(queryParameters.get("UserIdHeader"), queryParameters.get("UserIdIncomeBellwethersValue"));
        incomeBellwethersParameters.put(queryParameters.get("ViewNoHeader"), queryParameters.get("ViewNoValue"));
        incomeBellwethersParameters.put(queryParameters.get("PortfolioIdHeader"), queryParameters.get("PortfolioIdIncomeBellwethersValue"));
        incomeBellwethersParameters.put(queryParameters.get("WatchListNameHeader"), queryParameters.get("WatchListNameIncomeBellwethersValue"));
        incomeBellwethersParameters.put(queryParameters.get("ProductCodeHeader"), queryParameters.get("MdiValue"));
        researchRecords(incomeBellwethersParameters);
    }
}