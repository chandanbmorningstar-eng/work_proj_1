package com.morningstar.newsLettersApi.tests;

import com.morningstar.framework.SoftAssert;
import com.morningstar.newsLettersApi.common.Endpoints;
import com.morningstar.newsLettersApi.common.RequestResponseBase;
import com.morningstar.newsLettersApi.service.MFIFundInvestorService;
import io.restassured.specification.RequestSpecification;
import org.apache.http.HttpStatus;
import org.junit.Assert;
import org.junit.jupiter.api.Test;

import java.util.*;

import static io.restassured.RestAssured.given;

public class MFIFundInvestorSpyTest extends RequestResponseBase {
    static SoftAssert softAssert = new SoftAssert();

    /**
     * This testcase verify the category group response for each field with a null check with the help of an assertion
     */
    @Test
    public void testVerifyFund500CategoryGroupList() {
        List<Map> categoryGroup = getAndReturnAPI(given().request(), Endpoints.MFIFund500CategoryGroupList, HttpStatus.SC_OK).jsonPath().get();
        MFIFundInvestorService.verifyCategoryGroupResponse(categoryGroup, softAssert);
    }

    /**
     * This testcase verify the response of Category Details field with a null check with the help of an assertion
     */
    @Test
    public void testVerifyFund500PerCategoryDetails() {
        List<Map> categoryGroupResponse = getAndReturnAPI(given().request(), Endpoints.MFIFund500CategoryGroupList, HttpStatus.SC_OK).jsonPath().get();
        Assert.assertNotNull("Category Group is null", categoryGroupResponse);
        Assert.assertTrue("Category Group List should contain more than one element", categoryGroupResponse.size() > 1);

        for (int categoryIndex = 0; categoryIndex < categoryGroupResponse.size(); categoryIndex++) {
            String categoryShortCode = categoryGroupResponse.get(categoryIndex).get("ShortCode").toString();
            // If the value of categoryShortCode is allCat it will ignore the if block statement, and move to the next iteration
            if (!categoryShortCode.equalsIgnoreCase("AllCat")) {
                RequestSpecification requestSpecificationShortCode = given().request().queryParams("ShortCode", categoryShortCode);
                List<Map> fundDetailsResponse = getAndReturnAPI(requestSpecificationShortCode, Endpoints.MFIM500Funds, HttpStatus.SC_OK).jsonPath().get();
                MFIFundInvestorService.verifyFundDetails(fundDetailsResponse, softAssert);
            }
        }
        softAssert.assertAll();
    }

    /**
     * This testcase verify FundSpySelector response each field with a null check with the help of an assertion
     */
    @Test
    public void testVerifyFundSpySelector() {
        List<Map> categoryGroupResponse = getAndReturnAPI(given().request(), Endpoints.MFIFund500CategoryGroupList, HttpStatus.SC_OK).jsonPath().get();

        Assert.assertNotNull("Category Group is null", categoryGroupResponse);
        Assert.assertTrue("Category Group List should contain more than one element", categoryGroupResponse.size() > 1);

        for (int categoryIndex = 0; categoryIndex < categoryGroupResponse.size(); categoryIndex++) {
            String categoryShortCode = categoryGroupResponse.get(categoryIndex).get("ShortCode").toString();
            // If the value of categoryShortCode is allCat it will ignore the if block statement, and move to the next iteration
            if (!categoryShortCode.equalsIgnoreCase("AllCat")) {
                RequestSpecification requestSpecificationShortCode = given().request().queryParams("ShortCode", categoryShortCode);
                List<Map> fundDetailsResponse = getAndReturnAPI(requestSpecificationShortCode, Endpoints.MFIM500Funds, HttpStatus.SC_OK).jsonPath().get();
                Assert.assertNotNull("fundDetailsResponse  is null", fundDetailsResponse);
                Assert.assertTrue("fundDetailsResponse is empty", fundDetailsResponse.size() > 0);
                for (int fundDetailsTickerIndex = 0; fundDetailsTickerIndex < fundDetailsResponse.size(); fundDetailsTickerIndex++) {
                    String ticker = fundDetailsResponse.get(fundDetailsTickerIndex).get("Symbol").toString();
                    RequestSpecification requestSpecificationTicker = given().request().queryParams("ticker", ticker);
                    List<Map> fundSpyResponse = getAndReturnAPI(requestSpecificationTicker, Endpoints.MFIFundSpySelector, HttpStatus.SC_OK).jsonPath().get();
                    MFIFundInvestorService.verifyFundSpySelector(fundSpyResponse, softAssert);
                }
            }
        }
        softAssert.assertAll();
    }

    /**
     * This testcase verify Fund500CategoryGroupDetails, check the response for each field with a null check with the help of an assertion
     */
    @Test
    public void testVerifyFund500CategoryGroupDetails() {
        List<Map> categoryGroupResponse = getAndReturnAPI(given().request(), Endpoints.MFIFund500CategoryDetails, HttpStatus.SC_OK).jsonPath().get();
        MFIFundInvestorService.verifyCategoryGroupDetails(categoryGroupResponse, softAssert);
    }

    /*
     * This testcase verify total number of ticker should be 500 and unique ticker
     */
    @Test
    public void testVerifyTotalUniqueTickers() {
        List<Map> categoryGroupResponse = getAndReturnAPI(given().request(), Endpoints.MFIFund500CategoryGroupList, HttpStatus.SC_OK).jsonPath().get();
        Assert.assertNotNull("Category Group is null", categoryGroupResponse);
        Assert.assertTrue("Category Group List should contain more than one element", categoryGroupResponse.size() > 1);

        Map<String, List<String>> perCategoryTickers = new LinkedHashMap<>();
        Set<String> duplicateTickersList = new HashSet<>();
        Set<String> normalTickersList = new HashSet<>();
        String tempTicker;
        int allTickerCount = 0;

        for (int categoryIndex = 0; categoryIndex < categoryGroupResponse.size(); categoryIndex++) {
            String categoryShortCode = categoryGroupResponse.get(categoryIndex).get("ShortCode").toString();
            // If the value of categoryShortCode is allCat it will ignore the if block statement, and move to the next iteration
            if (!categoryShortCode.equalsIgnoreCase("AllCat")) {
                RequestSpecification requestSpecificationShortCode = given().request().queryParams("ShortCode", categoryShortCode);
                List<Map> fundDetailsResponse = getAndReturnAPI(requestSpecificationShortCode, Endpoints.MFIM500Funds, HttpStatus.SC_OK).jsonPath().get();
                Assert.assertNotNull("fundDetails category = " + categoryShortCode + " is null", fundDetailsResponse);
                Assert.assertTrue("fundDetails category = " + categoryShortCode + " List should contain elements", fundDetailsResponse.size() > 0);
                ArrayList<String> tickerPerCategory = new ArrayList<>();
                for (int fundIndex = 0; fundIndex < fundDetailsResponse.size(); fundIndex++) {
                    tempTicker = fundDetailsResponse.get(fundIndex).get("Symbol").toString().trim();
                    tickerPerCategory.add(tempTicker);
                    if (!(normalTickersList.add(tempTicker))) {
                        duplicateTickersList.add(tempTicker);
                    }
                }
                perCategoryTickers.put(categoryShortCode, tickerPerCategory);
                allTickerCount = allTickerCount + fundDetailsResponse.size();
            }
        }
        MFIFundInvestorService.verifyTotalDuplicateTickers(duplicateTickersList, perCategoryTickers, allTickerCount, softAssert);
    }

    /**
     * This testcase verify CategoryOverview, check the response for each field with a null check with the help of an assertion
     */
    @Test
    public void testVerifyCategoryOverview() {
        List<Map> categoryResponse = getAndReturnAPI(given().request(), Endpoints.ETFCategoryOverview, HttpStatus.SC_OK).jsonPath().get();
        MFIFundInvestorService.verifyCategoryOverview(categoryResponse, softAssert);
    }

    /**
     * This testcase verify testVerifyCategoryOverviewDetails, check the response for each field with a null check with the help of an assertion
     */
    @Test
    public void testVerifyCategoryOverviewDetails() {
        List<String> categoryIgnore = Arrays.asList("Currency", "Infrastructure Funds", "Stable Value", "Systematic Trend");
        List<Map> categoryResponse = getAndReturnAPI(given().request(), Endpoints.ETFCategoryOverview, HttpStatus.SC_OK).jsonPath().get();
        Assert.assertNotNull("Category Overview is null", categoryResponse);
        Assert.assertTrue("Category Overview is empty", categoryResponse.size() > 0);
        String categoryOverViewId, categoryName;
        for (int categoryIndex = 0; categoryIndex < categoryResponse.size(); categoryIndex++) {
            categoryOverViewId = categoryResponse.get(categoryIndex).get("Id").toString();
            categoryName = categoryResponse.get(categoryIndex).get("Name").toString();
            // If the value of categoryName is not matching with categoryIgnore it will ignore the if block statement, and move to the next iteration
            if (!categoryIgnore.contains(categoryName)) {
                RequestSpecification requestSpecificationCategoryOverView = given().request().queryParams("CategoryID", categoryOverViewId);
                List<Map> fundDetailsResponse = getAndReturnAPI(requestSpecificationCategoryOverView, Endpoints.ETFCategoryOverview, HttpStatus.SC_OK).jsonPath().get();
                MFIFundInvestorService.verifyCategoryOverviewDetails(categoryName, fundDetailsResponse, softAssert);
            }
        }
        softAssert.assertAll();
    }
}