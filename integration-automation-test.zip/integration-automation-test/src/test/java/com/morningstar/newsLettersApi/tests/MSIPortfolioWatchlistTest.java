package com.morningstar.newsLettersApi.tests;

import com.morningstar.newsLettersApi.common.Endpoints;
import com.morningstar.newsLettersApi.service.MSIFundInvestorService;
import com.morningstar.newsLettersApi.utility.TestDataUtility;
import org.apache.commons.collections.map.HashedMap;
import org.apache.http.HttpStatus;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import java.util.List;
import java.util.Map;

import static io.restassured.RestAssured.given;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class MSIPortfolioWatchlistTest extends MSIFundInvestorService {

    Map<String, String> params;

    /*
     * setup method - retrieving the headers and query parameters and storing in params variable
     * */
    @BeforeAll
    public void setup() {
        String testDataFileName = "portfolioWatchlistParams";
        params = (Map) TestDataUtility.getHeadersAndQueryParam(testDataFileName);
    }

    /**
     * This testcase verify the Tortoise portfolio response for each field with a null check with the help of an assertion
     */
    @Test
    public void testVerifyTortoisePortfolio() {
        Map<String, String> tortoiseParams = new HashedMap();
        tortoiseParams.put(params.get("UserIdTortoisePortfolioHeader"), params.get("UserIdTortoisePortfolioValue"));
        tortoiseParams.put(params.get("PortfolioIdTortoiseHeader"), params.get("PortfolioIdTortoiseValue"));
        tortoiseParams.put(params.get("ViewNoHeader"), params.get("ViewNoValue"));
        tortoiseParams.put(params.get("ProductCodeValue"), params.get("MsiValue"));
        List<Map> tortoisePortfolioResponse = getAndReturnAPI(given().request().queryParams(tortoiseParams), Endpoints.MSITortoiseHarePortfolioAndWatchlist, HttpStatus.SC_OK).jsonPath().get();

        boolean isTortoiseAndHareWatchlist = false;
        MSIFundInvestorService.verifyMSIPortfolioWatchlistResponseBody(tortoisePortfolioResponse, isTortoiseAndHareWatchlist);

    }

    /**
     * This testcase verify the select Income Bellwethers Record response and size should be less or equal 10.
     */
    @Test
    public void testVerifyTortoisePortfolioResearchRecord() {
        Map<String, String> tortoiseParams = new HashedMap();
        tortoiseParams.put(params.get("UserIdTortoisePortfolioHeader"), params.get("UserIdTortoisePortfolioValue"));
        tortoiseParams.put(params.get("PortfolioIdTortoiseHeader"), params.get("PortfolioIdTortoiseValue"));
        tortoiseParams.put(params.get("ViewNoHeader"), params.get("ViewNoValue"));
        tortoiseParams.put(params.get("ProductCodeValue"), params.get("MsiValue"));

        researchRecords(tortoiseParams);
    }

    /**
     * This testcase verify the Hare response for each field with a null check with the help of an assertion
     */
    @Test
    public void testVerifyHarePortfolio() {
        Map<String, String> hareParams = new HashedMap();
        hareParams.put(params.get("UserIdHarePortfolioHeader"), params.get("UserIdHarePortfolioValue"));
        hareParams.put(params.get("PortfolioIdHareHeader"), params.get("PortfolioIdHareValue"));
        hareParams.put(params.get("ViewNoHeader"), params.get("ViewNoValue"));
        hareParams.put(params.get("ProductCodeValue"), params.get("MsiValue"));

        List<Map> harePortfolioResponse = getAndReturnAPI(given().request().queryParams(hareParams), Endpoints.MSITortoiseHarePortfolioAndWatchlist, HttpStatus.SC_OK).jsonPath().get();

        boolean isTortoiseAndHareWatchlist = false;
        MSIFundInvestorService.verifyMSIPortfolioWatchlistResponseBody(harePortfolioResponse, isTortoiseAndHareWatchlist);
    }

    /**
     * This testcase verify the select VerifyHarePortfolioResearchRecord response and size should be less or equal 10.
     */
    @Test
    public void testVerifyHarePortfolioResearchRecord() {
        Map<String, String> hareParams = new HashedMap();
        hareParams.put(params.get("UserIdHarePortfolioHeader"), params.get("UserIdHarePortfolioValue"));
        hareParams.put(params.get("PortfolioIdHareHeader"), params.get("PortfolioIdHareValue"));
        hareParams.put(params.get("ViewNoHeader"), params.get("ViewNoValue"));
        hareParams.put(params.get("ProductCodeValue"), params.get("MsiValue"));

        researchRecords(hareParams);
    }

    /**
     * This testcase verify the Tortoise hare watchlist response for each field with a null check with the help of an assertion
     */
    @Test
    public void testVerifyTortoiseAndHareWatchlist() {
        Map<String, String> tortoiseHareParams = new HashedMap();
        tortoiseHareParams.put(params.get("UserIdTortoiseAndHareWatchlistHeader"), params.get("UserIdTortoiseAndHareWatchlistValue"));
        tortoiseHareParams.put(params.get("PortfolioIdTortoiseAndHareWatchlistHeader"), params.get("PortfolioIdTortoiseAndHareWatchlistValue"));
        tortoiseHareParams.put(params.get("ViewNoHeader"), params.get("ViewNoValue"));
        tortoiseHareParams.put(params.get("WatchListNameHeader"), params.get("WatchListNameValue"));
        tortoiseHareParams.put(params.get("ProductCodeValue"), params.get("MsiValue"));

        List<Map> tortoiseAndHareWatchlistResponse = getAndReturnAPI(given().request().queryParams(tortoiseHareParams),
                Endpoints.MSITortoiseHarePortfolioAndWatchlist, HttpStatus.SC_OK).jsonPath().get();

        boolean isTortoiseAndHareWatchlist = true;
        MSIFundInvestorService.verifyMSIPortfolioWatchlistResponseBody(tortoiseAndHareWatchlistResponse, isTortoiseAndHareWatchlist);
    }

    /**
     * This testcase verify the select VerifyTortoiseAndHareWatchlistResearchRecord response and size should be less or equal 10.
     */
    @Test
    public void testVerifyTortoiseAndHareWatchlistResearchRecord() {
        Map<String, String> tortoiseHareParams = new HashedMap();
        tortoiseHareParams.put(params.get("UserIdTortoiseAndHareWatchlistHeader"), params.get("UserIdTortoiseAndHareWatchlistValue"));
        tortoiseHareParams.put(params.get("PortfolioIdTortoiseAndHareWatchlistHeader"), params.get("PortfolioIdTortoiseAndHareWatchlistValue"));
        tortoiseHareParams.put(params.get("ViewNoHeader"), params.get("ViewNoValue"));
        tortoiseHareParams.put(params.get("WatchListNameHeader"), params.get("WatchListNameValue"));
        tortoiseHareParams.put(params.get("ProductCodeValue"), params.get("MsiValue"));
        researchRecords(tortoiseHareParams);
    }

    /**
     * This testcase verify Tortoise Portfolio Analysis Report
     */
    @Test
    public void testVerifyTortoisePortfolioAnalysisReport() {
        Map<String, String> tortoiseParams = new HashedMap();
        tortoiseParams.put(params.get("UserIdTortoisePortfolioHeader"), params.get("UserIdTortoisePortfolioValue"));
        tortoiseParams.put(params.get("PortfolioIdTortoiseHeader"), params.get("PortfolioIdTortoiseValue"));
        tortoiseParams.put(params.get("ViewNoHeader"), params.get("ViewNoValue"));
        tortoiseParams.put(params.get("ProductCodeValue"), params.get("MsiValue"));

        Map<String, String> analysisReportParams = new HashedMap();
        analysisReportParams.put(params.get("ProductCodeValue"), params.get("MsiValue"));
        verifyMSIAnalysisReport(tortoiseParams, analysisReportParams);
    }

    /**
     * This testcase verify Hare Analysis Report
     */
    @Test
    public void testVerifyHarePortfolioAnalysisReport() {
        Map<String, String> hareParams = new HashedMap();
        hareParams.put(params.get("UserIdHarePortfolioHeader"), params.get("UserIdHarePortfolioValue"));
        hareParams.put(params.get("PortfolioIdHareHeader"), params.get("PortfolioIdHareValue"));
        hareParams.put(params.get("ViewNoHeader"), params.get("ViewNoValue"));
        hareParams.put(params.get("ProductCodeValue"), params.get("MsiValue"));

        Map<String, String> analysisReportParams = new HashedMap();
        analysisReportParams.put(params.get("ProductCodeValue"), params.get("MsiValue"));
        verifyMSIAnalysisReport(hareParams, analysisReportParams);
    }

    /**
     * This testcase verify Tortoise And Hare Watchlist Analysis Report
     */
    @Test
    public void testVerifyTortoiseAndHareWatchlistAnalysisReport() {
        Map<String, String> tortoiseHareParams = new HashedMap();
        tortoiseHareParams.put(params.get("UserIdTortoiseAndHareWatchlistHeader"), params.get("UserIdTortoiseAndHareWatchlistValue"));
        tortoiseHareParams.put(params.get("PortfolioIdTortoiseAndHareWatchlistHeader"), params.get("PortfolioIdTortoiseAndHareWatchlistValue"));
        tortoiseHareParams.put(params.get("ViewNoHeader"), params.get("ViewNoValue"));
        tortoiseHareParams.put(params.get("WatchListNameHeader"), params.get("WatchListNameValue"));
        tortoiseHareParams.put(params.get("ProductCodeValue"), params.get("MsiValue"));

        Map<String, String> analysisReportParams = new HashedMap();
        analysisReportParams.put(params.get("ProductCodeValue"), params.get("MsiValue"));
        verifyMSIAnalysisReport(tortoiseHareParams, analysisReportParams);
    }
}