package com.morningstar.newsLettersApi.tests;

import com.morningstar.newsLettersApi.common.Endpoints;
import com.morningstar.newsLettersApi.common.RequestResponseBase;
import com.morningstar.newsLettersApi.service.NewsLettersService;
import org.apache.http.HttpStatus;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static io.restassured.RestAssured.given;

public class NewsLettersTest extends RequestResponseBase {

    /**
     * This testcase verify the image base 64 string response
     */
    @Test
    public void testVerifyFileContent() {
        List<Map> fileContentList = getAndReturnAPI(given().request(), Endpoints.HomePageCoverImages, HttpStatus.SC_OK).jsonPath().get("FileContent");
        NewsLettersService.verifyMSIPortfolioWatchlistResponseBody(fileContentList);
    }
}