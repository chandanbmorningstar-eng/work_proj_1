package com.morningstar.newsLettersApi.utility;

import com.morningstar.newsLettersApi.config.ConfigurationManager;
import com.morningstar.newsLettersApi.config.Environment;
import com.morningstar.newsLettersApi.config.NewsLetterConfig;
import java.util.Optional;

public class FunctionalUtilities {

    //This Method returns the baseUrl
    public static String getBaseUrl() {
        NewsLetterConfig newsLetterApi = ConfigurationManager.getSettings().getNewsLettersApi();
        String baseUrl = newsLetterApi.getBaseUrl().toString();
        return baseUrl;
    }

    //This Method returns the environment value
    public static String getEnv() {
        return Optional.ofNullable(System.getProperty("env")).orElseGet(() -> Environment.env);
    }
}