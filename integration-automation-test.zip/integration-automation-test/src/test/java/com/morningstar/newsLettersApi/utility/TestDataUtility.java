package com.morningstar.newsLettersApi.utility;

import com.google.gson.Gson;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;

public class TestDataUtility {

    /*
     * This method is used to read JSON file and parse it into JsonObject
     * */
    public static JSONObject getJsonFileData(String jsonFileName) {
        JSONObject jsonFileContent = null;
        String filePath = "src" + File.separator + "test" + File.separator + "resources" + File.separator + "testdata" + File.separator + jsonFileName + ".json";
        try {
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(new FileReader(filePath));
            jsonFileContent = (JSONObject) obj;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsonFileContent;
    }

    public static Object getHeadersAndQueryParam(String jsonFileName) {

        BufferedReader reader = null;
        try {
            reader = Files.newBufferedReader(Paths.get(System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\" + FunctionalUtilities.getEnv().toUpperCase().trim() + "\\" + jsonFileName + ".json"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new Gson().fromJson(reader, Map.class);
    }

    /*
     * Getting file path for test data newsletter
     * */
    public static String getFilePath(String fileName, String newsLetter) {
        String filePath = System.getProperty("user.dir") + File.separator + "src" + File.separator + "test" +
                File.separator + "resources" + File.separator +
                "testdata" + File.separator + newsLetter + File.separator + fileName + ".txt";
        return filePath;
    }
}